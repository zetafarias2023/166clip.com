// Uso: npm run set-owner -- tu@gmail.com
// Deja tu Gmail como único dueño/admin en las reglas y en la web.
import { readFileSync, writeFileSync } from "node:fs";

const email = (process.argv[2] || "").trim().toLowerCase();
if (!/^[^\s@']+@[^\s@']+\.[^\s@']+$/.test(email)) {
  console.error("Uso: npm run set-owner -- tu@gmail.com");
  process.exit(1);
}
for (const f of ["firestore.rules", "storage.rules", "src/config.ts"]) {
  const s = readFileSync(f, "utf8");
  const out = s.replace(/OWNER_EMAIL_PLACEHOLDER|(?<=email == ')[^']*(?=')|(?<=OWNER_EMAIL = ")[^"]*(?=")/g, email);
  writeFileSync(f, out);
  console.log("Actualizado", f);
}
console.log("Listo. Ahora publicá: firebase deploy --only firestore:rules,storage");
