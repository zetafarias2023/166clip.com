# Avisos push (opcional, requiere plan Blaze)

1. Firebase Console > Configuración del proyecto > Cloud Messaging > Certificados push web > generá el par de claves
   y copiá la clave pública. En Netlify (Site settings > Environment) agregá `VITE_FCM_VAPID_KEY` con ese valor.
2. En `firebase.json` agregá: `"functions": { "source": "functions" }`.
3. `cd functions && npm install && cd .. && firebase deploy --only functions`.
4. En la app, entrá a Chats y tocá "Activar avisos" en cada dispositivo.
