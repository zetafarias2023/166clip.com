// Aviso push cuando llega un mensaje. Requiere plan Blaze. Ver functions/README.md.
const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");
admin.initializeApp();

exports.notifyMessage = onDocumentCreated("conversations/{cid}/messages/{mid}", async (event) => {
  const m = event.data && event.data.data();
  if (!m) return;
  const db = admin.firestore();
  const conv = (await db.doc(`conversations/${event.params.cid}`).get()).data();
  const to = conv && (conv.participants || []).find((p) => p !== m.from);
  if (!to) return;
  const lists = (await db.doc(`userLists/${to}`).get()).data() || {};
  if ((lists.muted || []).includes(m.from) || (lists.blocked || []).includes(m.from)) return;
  const tok = (await db.doc(`fcmTokens/${to}`).get()).data();
  if (!tok || !tok.token) return;
  const body = m.aud ? "🎤 Audio" : m.img ? "📷 Foto" : String(m.text || "").slice(0, 120);
  await admin.messaging().send({
    token: tok.token,
    data: { title: (conv.names && conv.names[m.from]) || "Chatcrack", body, url: `/mensajes/${m.from}` },
    webpush: { headers: { Urgency: "high" } },
  });
});
