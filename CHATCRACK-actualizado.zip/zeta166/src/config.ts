/** Categorías de trabajo de los editores (las mismas del proyecto original). */
export const CATS = [
  "Edición de video",
  "Miniaturas",
  "Animación",
  "Overlays y stream",
  "Música y sonido",
] as const;

/** Degradados para la tarjeta de perfil y para la foto cuando no hay una subida. */
export const COLS = [
  "linear-gradient(135deg,#8B5CFF,#C6FF3D)",
  "linear-gradient(135deg,#FF4D6D,#FFB347)",
  "linear-gradient(135deg,#00D1FF,#8B5CFF)",
  "linear-gradient(135deg,#00E58F,#00A3FF)",
  "linear-gradient(135deg,#FF5CF4,#7A5CFF)",
  "linear-gradient(135deg,#F2F2F7,#8A8FA3)",
];

export const MAX_WORKS = 12;
const MB = 1024 * 1024;
export const MAX_BYTES = { portfolio: 25 * MB };

/** Tu Gmail de dueño. Se completa con `npm run set-owner -- tu@gmail.com`. */
export const OWNER_EMAIL = "fariaszeta794@gmail.com";
export const IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];

/** Máximo de perfiles que se descargan para el directorio (ver README, sección "Escala"). */
export const PROFILE_LIMIT = 200;
export const MESSAGE_LIMIT = 100;

export const MIN_AGE = 13;

/** Cuenta de PayPal que recibe los pagos y precio (en dólares) de Chatcrack Pro. */
export const PAYPAL_EMAIL = "fariaszeta794@gmail.com";
export const PRO_PRICE_USD = 5;

/** Completá estos datos: se usan en Privacidad y Términos. */
export const LEGAL = {
  date: "[FECHA]",
  owner: "[TU NOMBRE O RAZÓN SOCIAL]",
  country: "[PAÍS]",
  email: "[TU MAIL]",
};
