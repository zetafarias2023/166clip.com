import { collection, deleteDoc, doc, getDoc, onSnapshot, serverTimestamp, setDoc } from "firebase/firestore";
import { PAYPAL_EMAIL, PRO_PRICE_USD } from "../config";
import { db } from "../firebase/client";
import type { ProRequest } from "../types";

/** Enlace de pago de PayPal (pago único). `custom` lleva tu UID para reconocer el pago. */
export function paypalUrl(uid: string): string {
  const q = new URLSearchParams({
    cmd: "_xclick",
    business: PAYPAL_EMAIL,
    item_name: "Chatcrack Pro - todos los avatares",
    amount: PRO_PRICE_USD.toFixed(2),
    currency_code: "USD",
    no_shipping: "1",
    no_note: "1",
    custom: uid,
    return: `${window.location.origin}/panel`,
    cancel_return: `${window.location.origin}/panel`,
  });
  return `https://www.paypal.com/cgi-bin/webscr?${q.toString()}`;
}

/** ¿Ya es Pro? ¿Tiene un pago esperando revisión? */
export async function fetchProStatus(uid: string): Promise<{ pro: boolean; pending: boolean }> {
  const [p, r] = await Promise.all([getDoc(doc(db, "proUsers", uid)), getDoc(doc(db, "proRequests", uid))]);
  return { pro: p.exists(), pending: r.exists() };
}

/** El usuario avisa que pagó e indica el ID de transacción de PayPal. */
export const requestPro = (uid: string, name: string, txn: string) =>
  setDoc(doc(db, "proRequests", uid), { name: name.slice(0, 40), txn: txn.trim().slice(0, 40), at: serverTimestamp() });

/* Administración */

export function subscribeProRequests(cb: (rows: ProRequest[]) => void): () => void {
  return onSnapshot(
    collection(db, "proRequests"),
    (s) => cb(s.docs.map((d) => ({ id: d.id, ...(d.data() as { name?: string; txn?: string }) }))),
    () => cb([]),
  );
}

export async function approvePro(uid: string): Promise<void> {
  await setDoc(doc(db, "proUsers", uid), { at: serverTimestamp() });
  await deleteDoc(doc(db, "proRequests", uid));
}

export const rejectPro = (uid: string) => deleteDoc(doc(db, "proRequests", uid));
