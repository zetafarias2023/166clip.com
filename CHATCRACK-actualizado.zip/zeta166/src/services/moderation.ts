import { collection, deleteDoc, doc, onSnapshot, serverTimestamp, setDoc } from "firebase/firestore";
import { db } from "../firebase/client";
import type { Report, VerifyRequest } from "../types";

/* Acciones de cualquier usuario con sesión */

export const requestVerification = (uid: string, name: string) =>
  setDoc(doc(db, "verifyRequests", uid), { name: name.slice(0, 40), at: serverTimestamp() });

/** Un reporte por persona y perfil: el id evita el reenvío masivo. */
export const reportProfile = (by: string, profileId: string, reason: string) =>
  setDoc(doc(db, "reports", `${by}_${profileId}`), {
    profileId,
    by,
    reason: reason.slice(0, 300),
    at: serverTimestamp(),
  });

/* Acciones de administración (las reglas de Firestore las limitan a admins) */

export function subscribeVerifyRequests(cb: (rows: VerifyRequest[]) => void): () => void {
  return onSnapshot(
    collection(db, "verifyRequests"),
    (s) => cb(s.docs.map((d) => ({ id: d.id, ...(d.data() as { name?: string }) }))),
    () => cb([]),
  );
}

export function subscribeReports(cb: (rows: Report[]) => void): () => void {
  return onSnapshot(
    collection(db, "reports"),
    (s) => cb(s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Report, "id">) }))),
    () => cb([]),
  );
}

export const setVerified = (uid: string, on: boolean) =>
  on ? setDoc(doc(db, "verified", uid), { at: serverTimestamp() }) : deleteDoc(doc(db, "verified", uid));

export const setFeatured = (uid: string, on: boolean) =>
  on ? setDoc(doc(db, "featured", uid), { at: serverTimestamp() }) : deleteDoc(doc(db, "featured", uid));

export async function approveVerification(uid: string): Promise<void> {
  await setDoc(doc(db, "verified", uid), { at: serverTimestamp() });
  await deleteDoc(doc(db, "verifyRequests", uid));
}

export const rejectVerification = (uid: string) => deleteDoc(doc(db, "verifyRequests", uid));
export const dismissReport = (id: string) => deleteDoc(doc(db, "reports", id));
