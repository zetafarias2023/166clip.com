import {
  collection, deleteDoc, doc, getCountFromServer, getDoc, getDocs, limit, query, serverTimestamp, setDoc, where,
} from "firebase/firestore";
import type { Timestamp } from "firebase/firestore";
import { PROFILE_LIMIT } from "../config";
import { db } from "../firebase/client";
import { compact } from "../lib/utils";
import type { Profile, ProfileInput } from "../types";
import { deleteByUrl } from "./storage";

const toProfile = (id: string, data: object): Profile => ({ id, ...(data as Omit<Profile, "id">) });

/** Una sola lectura (sin escucha en vivo) para no gastar lecturas de Firestore en cada cambio. */
export async function fetchProfiles(): Promise<Profile[]> {
  const s = await getDocs(query(collection(db, "profiles"), limit(PROFILE_LIMIT)));
  return s.docs.map((d) => toProfile(d.id, d.data()));
}

export async function fetchProfile(id: string): Promise<Profile | null> {
  const s = await getDoc(doc(db, "profiles", id));
  return s.exists() ? toProfile(s.id, s.data()) : null;
}

export async function saveProfile(uid: string, input: ProfileInput, createdAt?: Timestamp): Promise<void> {
  await setDoc(doc(db, "profiles", uid), compact({ ...input, createdAt: createdAt ?? serverTimestamp() }));
}

/** Borra el perfil, sus archivos y los seguimientos. Los chats se conservan para la otra persona. */
export async function deleteProfileCascade(uid: string, p?: Profile | null): Promise<void> {
  const urls = [p?.avatarUrl, p?.bannerUrl, ...(p?.works ?? []).map((w) => w.url)].filter(Boolean) as string[];
  await deleteDoc(doc(db, "profiles", uid));
  const [mine, theirs] = await Promise.all([
    getDocs(query(collection(db, "follows"), where("follower", "==", uid))),
    getDocs(query(collection(db, "follows"), where("followed", "==", uid))),
  ]);
  await Promise.allSettled([...mine.docs, ...theirs.docs].map((d) => deleteDoc(d.ref)));
  await Promise.allSettled(urls.map(deleteByUrl));
}

export async function countFollowers(id: string): Promise<number> {
  const s = await getCountFromServer(query(collection(db, "follows"), where("followed", "==", id)));
  return s.data().count;
}
