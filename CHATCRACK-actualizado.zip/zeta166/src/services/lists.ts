import { arrayRemove, arrayUnion, doc, onSnapshot, setDoc } from "firebase/firestore";
import { db } from "../firebase/client";

export type ListKey = "fav" | "archived" | "close" | "muted" | "blocked";
export type Lists = Record<ListKey, string[]>;
export const emptyLists = (): Lists => ({ fav: [], archived: [], close: [], muted: [], blocked: [] });

export function subscribeLists(uid: string, cb: (l: Lists) => void): () => void {
  return onSnapshot(
    doc(db, "userLists", uid),
    (s) => cb({ ...emptyLists(), ...((s.data() ?? {}) as Partial<Lists>) }),
    () => cb(emptyLists()),
  );
}

export const toggleInList = (uid: string, key: ListKey, other: string, on: boolean) =>
  setDoc(doc(db, "userLists", uid), { [key]: on ? arrayUnion(other) : arrayRemove(other) }, { merge: true });
