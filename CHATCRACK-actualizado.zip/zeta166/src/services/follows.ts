import { deleteDoc, doc, getDoc, serverTimestamp, setDoc } from "firebase/firestore";
import { db } from "../firebase/client";

const followId = (me: string, other: string) => `${me}_${other}`;

export async function isFollowing(me: string, other: string): Promise<boolean> {
  return (await getDoc(doc(db, "follows", followId(me, other)))).exists();
}

export const follow = (me: string, other: string) =>
  setDoc(doc(db, "follows", followId(me, other)), { follower: me, followed: other, at: serverTimestamp() });

export const unfollow = (me: string, other: string) => deleteDoc(doc(db, "follows", followId(me, other)));
