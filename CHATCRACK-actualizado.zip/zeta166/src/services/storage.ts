import { deleteObject, getDownloadURL, ref, uploadBytes } from "firebase/storage";
import { IMAGE_TYPES, MAX_BYTES } from "../config";
import { storage } from "../firebase/client";

export type Folder = keyof typeof MAX_BYTES;

/** Devuelve un mensaje de error en español, o null si el archivo es válido. */
export function checkImage(file: File, folder: Folder): string | null {
  if (!IMAGE_TYPES.includes(file.type)) return "Usá una imagen JPG, PNG, WEBP o GIF.";
  if (file.size >= MAX_BYTES[folder]) return `La imagen pesa demasiado. El máximo es ${MAX_BYTES[folder] / 1024 / 1024} MB.`;
  return null;
}

/**
 * Achica las fotos grandes (típicas del celular) antes de subirlas: suben mucho más rápido
 * y casi nunca superan el límite. Los GIF se dejan tal cual para no perder la animación.
 * Si algo falla, se sube el archivo original.
 */
async function shrink(file: File, maxSide: number): Promise<File> {
  if (file.type === "image/gif" || file.size < 600 * 1024) return file;
  try {
    const bmp = await createImageBitmap(file);
    const scale = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
    const w = Math.max(1, Math.round(bmp.width * scale));
    const h = Math.max(1, Math.round(bmp.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return file;
    ctx.drawImage(bmp, 0, 0, w, h);
    bmp.close?.();
    const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/jpeg", 0.85));
    if (!blob || blob.size >= file.size) return file;
    return new File([blob], file.name.replace(/\.\w+$/, "") + ".jpg", { type: "image/jpeg" });
  } catch {
    return file;
  }
}

export async function uploadImage(folder: Folder, uid: string, file: File): Promise<string> {
  const err = checkImage(file, folder);
  if (err) throw new Error(err);
  const ready = await shrink(file, 1920);
  const safe = ready.name.replace(/[^\w.\-]/g, "_").slice(-80);
  const r = ref(storage, `${folder}/${uid}/${Date.now()}_${safe}`);
  await uploadBytes(r, ready, { contentType: ready.type });
  return getDownloadURL(r);
}

/** Borra un archivo a partir de su enlace de descarga. Si ya no existe, no falla. */
export async function deleteByUrl(url: string): Promise<void> {
  try {
    await deleteObject(ref(storage, url));
  } catch {
    /* ya no existe o no es nuestro */
  }
}

/** Sube una nota de voz a chat/<uid>/. Máximo 10 MB. */
export async function uploadAudio(uid: string, blob: Blob): Promise<string> {
  if (blob.size >= 10 * 1024 * 1024) throw new Error("El audio es demasiado largo.");
  const ext = blob.type.includes("mp4") ? "m4a" : blob.type.includes("ogg") ? "ogg" : "webm";
  const r = ref(storage, `chat/${uid}/${Date.now()}_audio.${ext}`);
  await uploadBytes(r, blob, { contentType: blob.type.split(";")[0] || "audio/webm" });
  return getDownloadURL(r);
}
