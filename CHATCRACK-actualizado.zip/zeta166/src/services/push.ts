import { doc, serverTimestamp, setDoc } from "firebase/firestore";
import { getMessaging, getToken, isSupported } from "firebase/messaging";
import { app, db } from "../firebase/client";

/** Registra este dispositivo para avisos push (solo si cargaste VITE_FCM_VAPID_KEY, ver README). */
export async function registerPush(uid: string): Promise<void> {
  const vapidKey = import.meta.env.VITE_FCM_VAPID_KEY as string | undefined;
  if (!vapidKey || !("serviceWorker" in navigator)) return;
  try {
    if (!(await isSupported())) return;
    const reg = await navigator.serviceWorker.ready;
    const token = await getToken(getMessaging(app), { vapidKey, serviceWorkerRegistration: reg });
    if (token) await setDoc(doc(db, "fcmTokens", uid), { token, at: serverTimestamp() });
  } catch {
    /* sin push: siguen los avisos dentro de la página */
  }
}
