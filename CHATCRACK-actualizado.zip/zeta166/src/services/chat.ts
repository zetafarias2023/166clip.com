import {
  addDoc, collection, deleteDoc, deleteField, doc, limit, onSnapshot, orderBy, query, serverTimestamp, setDoc, updateDoc, where,
} from "firebase/firestore";
import { MESSAGE_LIMIT } from "../config";
import { db } from "../firebase/client";
import type { Conversation, Message } from "../types";

export const convId = (a: string, b: string) => [a, b].sort().join("_");

export function subscribeConversations(uid: string, cb: (rows: Conversation[]) => void): () => void {
  return onSnapshot(
    query(collection(db, "conversations"), where("participants", "array-contains", uid)),
    (s) => cb(s.docs.map((d) => ({ id: d.id, ...(d.data({ serverTimestamps: "estimate" }) as Omit<Conversation, "id">) }))),
    () => cb([]),
  );
}

/** Solo se escuchan los últimos mensajes (no todo el historial). */
export function subscribeMessages(cid: string, cb: (rows: Message[]) => void): () => void {
  return onSnapshot(
    query(collection(db, "conversations", cid, "messages"), orderBy("at", "desc"), limit(MESSAGE_LIMIT)),
    (s) =>
      cb(
        s.docs
          .map((d) => ({ id: d.id, ...(d.data({ serverTimestamps: "estimate" }) as Omit<Message, "id">) }))
          .reverse(),
      ),
    () => cb([]),
  );
}

interface Person {
  uid: string;
  name: string;
}

export async function sendMessage(me: Person, other: Person, payload: { text?: string; img?: string; aud?: string; dur?: number; reply?: { id: string; text: string; from: string } }): Promise<void> {
  const text = payload.text?.trim();
  if (!text && !payload.img && !payload.aud) return;
  const cid = convId(me.uid, other.uid);
  await setDoc(
    doc(db, "conversations", cid),
    {
      participants: [me.uid, other.uid].sort(),
      names: { [me.uid]: me.name.slice(0, 40), [other.uid]: other.name.slice(0, 40) },
      lastText: payload.aud ? "Audio" : payload.img ? "Foto" : (text as string).slice(0, 80),
      lastFrom: me.uid,
      lastAt: serverTimestamp(),
    },
    { merge: true },
  );
  await addDoc(collection(db, "conversations", cid, "messages"), {
    from: me.uid,
    ...(payload.aud ? { aud: payload.aud, dur: payload.dur ?? 0 } : payload.img ? { img: payload.img } : { text }),
    ...(payload.reply ? { reply: payload.reply } : {}),
    at: serverTimestamp(),
  });
}

export const markSeen = (cid: string, uid: string) =>
  updateDoc(doc(db, "conversations", cid), { [`seen.${uid}`]: serverTimestamp() });

/** Borra un mensaje propio para ambas personas. */
export const deleteMessage = (cid: string, mid: string) => deleteDoc(doc(db, "conversations", cid, "messages", mid));

/** "Eliminar chat" solo para vos: oculta el historial hasta ahora. La otra persona lo conserva. */
export const clearConversation = (cid: string, uid: string) =>
  updateDoc(doc(db, "conversations", cid), { [`cleared.${uid}`]: serverTimestamp() });

/** Avisa que estás escribiendo (el chat debe existir). */
export const setTyping = (cid: string, uid: string) =>
  updateDoc(doc(db, "conversations", cid), { [`typing.${uid}`]: serverTimestamp() });

/** Reacciona con un emoji a un mensaje (o quita la reacción si emoji es null). */
export async function reactToMessage(cid: string, mid: string, uid: string, emoji: string | null): Promise<void> {
  await updateDoc(doc(db, "conversations", cid, "messages", mid), {
    [`react.${uid}`]: emoji === null ? deleteField() : emoji,
  });
}

/** Presencia: "en línea" / "últ. vez". */
export const pingPresence = (uid: string) => setDoc(doc(db, "presence", uid), { at: serverTimestamp() });

export function subscribePresence(uid: string, cb: (ms: number) => void): () => void {
  return onSnapshot(
    doc(db, "presence", uid),
    (s) => {
      const t = (s.data() as { at?: { toMillis(): number } } | undefined)?.at;
      cb(t ? t.toMillis() : 0);
    },
    () => cb(0),
  );
}
