import { cx } from "../lib/utils";

export const Skeleton = ({ className }: { className?: string }) => <div className={cx("skeleton", className)} aria-hidden="true" />;

export function ProfileCardSkeleton() {
  return (
    <div className="overflow-hidden rounded-2xl border border-line bg-surface" aria-hidden="true">
      <Skeleton className="h-20 rounded-none" />
      <div className="space-y-3 p-4">
        <Skeleton className="-mt-10 h-12 w-12 rounded-full" />
        <Skeleton className="h-4 w-2/3" />
        <Skeleton className="h-3 w-1/2" />
        <Skeleton className="h-3 w-3/4" />
      </div>
    </div>
  );
}
