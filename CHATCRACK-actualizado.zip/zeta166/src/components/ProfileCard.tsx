import { Link } from "react-router-dom";
import { useData } from "../hooks/useData";
import type { Profile } from "../types";
import { Avatar, Banner, VerifiedBadge } from "./Avatar";

export function ProfileCard({ p, mine }: { p: Profile; mine?: boolean }) {
  const { verified } = useData();
  return (
    <Link
      to={`/editor/${p.id}`}
      className="group block overflow-hidden rounded-2xl border border-line bg-surface transition hover:-translate-y-0.5 hover:border-violet hover:shadow-violet focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neon"
    >
      <Banner profile={p} className="h-20" />
      <div className="px-4 pb-4">
        <Avatar profile={p} size={52} className="-mt-7 border-2 border-surface" />
        <h3 className="mt-2 flex items-center gap-1.5 font-display text-lg font-semibold leading-tight">
          <span className="truncate">{p.name}</span>
          {verified.has(p.id) && <VerifiedBadge />}
        </h3>
        <p className="text-sm text-violet-soft">
          {p.cat}
          {mine ? " · Tu perfil" : ""}
        </p>
        {p.soft && <p className="mt-1 truncate text-sm text-mute">{p.soft}</p>}
        <div className="mt-3 flex items-center justify-between gap-2 text-sm">
          <span className="flex items-center gap-1.5 text-mute">
            <span className={"h-2 w-2 rounded-full " + (p.av ? "bg-neon shadow-[0_0_8px_#B6FF2E]" : "bg-mute/50")} />
            {p.av ? "Disponible" : "Sin cupo ahora"}
          </span>
          {p.price && <span className="truncate font-medium text-white">Desde {p.price}</span>}
        </div>
      </div>
    </Link>
  );
}
