import { BadgeCheck } from "lucide-react";
import { COLS } from "../config";
import { AvatarArt, isAvatarId } from "../lib/avatars";
import { cx, initial } from "../lib/utils";
import type { Profile } from "../types";

interface AvatarProps {
  profile?: Profile | null;
  name?: string;
  size?: number;
  className?: string;
}

export function Avatar({ profile, name, size = 44, className }: AvatarProps) {
  const style = { width: size, height: size, fontSize: size * 0.42 };
  if (profile && isAvatarId(profile.avatarId)) {
    return (
      <span style={style} className={cx("block shrink-0 overflow-hidden rounded-full border border-line bg-raise", className)}>
        <AvatarArt id={profile.avatarId} size={size} />
      </span>
    );
  }
  return (
    <div
      aria-hidden="true"
      style={{ ...style, background: COLS[(profile?.col ?? 0) % COLS.length] }}
      className={cx("grid shrink-0 place-items-center rounded-full font-display font-bold text-ink", className)}
    >
      {initial(profile?.name ?? name)}
    </div>
  );
}

export function Banner({ profile, className }: { profile?: Profile | null; className?: string }) {
  return <div aria-hidden="true" className={className} style={{ background: COLS[(profile?.col ?? 0) % COLS.length] }} />;
}

export function VerifiedBadge({ className }: { className?: string }) {
  return <BadgeCheck className={cx("inline h-[1.05em] w-[1.05em] shrink-0 text-neon", className)} aria-label="Verificado" role="img" />;
}
