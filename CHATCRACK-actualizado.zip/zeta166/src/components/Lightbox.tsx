import { useEffect } from "react";
import { X } from "lucide-react";

export function Lightbox({ url, title, onClose }: { url: string; title?: string; onClose: () => void }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-[95] grid place-items-center bg-black/90 p-4 animate-fade"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={title || "Imagen ampliada"}
    >
      <button type="button" onClick={onClose} className="absolute right-4 top-4 rounded-full bg-raise p-2 text-white" aria-label="Cerrar">
        <X className="h-5 w-5" />
      </button>
      <img src={url} alt={title || "Imagen ampliada"} className="max-h-[88vh] max-w-full rounded-lg object-contain" />
    </div>
  );
}
