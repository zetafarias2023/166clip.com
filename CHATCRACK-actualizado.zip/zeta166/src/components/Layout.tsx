import { useState } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import { Archive, Ban, BellOff, Compass, Heart, Lock, LogOut, Menu, MessageCircle, Sparkles, Star, User, X, type LucideIcon } from "lucide-react";
import type { Profile } from "../types";
import { useAuth } from "../hooks/useAuth";
import { useChat } from "../hooks/useChat";
import { useData } from "../hooks/useData";
import { useSignIn } from "../hooks/useSignIn";
import { useToast } from "../hooks/useToast";
import { cx } from "../lib/utils";
import { Avatar } from "./Avatar";

function Logo() {
  return (
    <Link to="/mensajes" className="flex items-baseline gap-2 font-display" aria-label="Chatcrack, ir al inicio">
      <span className="text-2xl font-bold tracking-tight text-white">Chat<span className="text-neon">crack</span></span>
    </Link>
  );
}

const MENU: Array<[string, string, LucideIcon]> = [
  ["/cuenta/favoritos", "Favoritos", Star],
  ["/cuenta/archivados", "Archivados", Archive],
  ["/cuenta/privacidad", "Privacidad del perfil", Lock],
  ["/cuenta/mejores-amigos", "Mejores amigos", Heart],
  ["/cuenta/silenciados", "Silenciados", BellOff],
  ["/cuenta/bloqueados", "Bloqueados", Ban],
];

const TABS: Array<[string, string, LucideIcon]> = [
  ["/mensajes", "Chats", MessageCircle],
  ["/inicio", "Para ti", Sparkles],
  ["/editores", "Explorar", Compass],
  ["/cuenta", "Cuenta", User],
];

function AccountMenu({ me, name, onSignOut }: { me?: Profile; name: string; onSignOut: () => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button type="button" aria-label="Mi cuenta" aria-expanded={open} onClick={() => setOpen((v) => !v)} className="rounded-full ring-2 ring-transparent transition hover:ring-violet">
        <Avatar profile={me} name={name} size={36} />
      </button>
      {open && (
        <>
          <button type="button" aria-label="Cerrar menú" className="fixed inset-0 z-40 cursor-default" onClick={() => setOpen(false)} />
          <div className="absolute right-0 z-50 mt-2 w-64 overflow-hidden rounded-2xl border border-line bg-surface shadow-violet animate-pop">
            <p className="truncate border-b border-line px-4 py-3 font-display font-semibold">{me?.name || name || "Mi cuenta"}</p>
            {MENU.map(([to, label, Icon]) => (
              <Link key={to} to={to} onClick={() => setOpen(false)} className="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-raise">
                <Icon className="h-4 w-4 text-violet-soft" /> {label}
              </Link>
            ))}
            <button type="button" onClick={() => { setOpen(false); onSignOut(); }} className="flex w-full items-center gap-3 border-t border-line px-4 py-2.5 text-left text-sm text-danger hover:bg-raise">
              <LogOut className="h-4 w-4" /> Salir
            </button>
          </div>
        </>
      )}
    </div>
  );
}

function InAppNotice() {
  const { user, inApp } = useAuth();
  const { push } = useToast();
  if (!inApp || user) return null;
  return (
    <div className="border-b border-violet/40 bg-violet/10 px-4 py-2 text-center text-sm">
      Estás viendo la web dentro de otra app. Para iniciar sesión con Google, abrila en Chrome o Safari.{" "}
      <button
        type="button"
        className="font-medium text-neon underline underline-offset-2"
        onClick={() =>
          navigator.clipboard
            ?.writeText(window.location.href)
            .then(() => push("Enlace copiado. Pegalo en tu navegador.", { tone: "ok" }))
            .catch(() => push("No se pudo copiar el enlace.", { tone: "error" }))
        }
      >
        Copiar enlace
      </button>
    </div>
  );
}

export function Layout() {
  const { user, isAdmin, signOut } = useAuth();
  const { unread } = useChat();
  const { profiles } = useData();
  const signIn = useSignIn();
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  const inChat = pathname.startsWith("/mensajes");
  const showTabs = !/^\/mensajes\/.+/.test(pathname);
  const me = profiles.find((p) => p.id === user?.uid);

  const link = ({ isActive }: { isActive: boolean }) =>
    cx("rounded-lg px-3 py-2 text-sm font-medium transition", isActive ? "bg-raise text-neon" : "text-mute hover:text-white");

  const nav = (
    <>
      <NavLink to="/mensajes" className={link} onClick={() => setOpen(false)}>Chats{unread > 0 && <span className="ml-1.5 rounded-full bg-neon px-1.5 py-0.5 text-xs font-bold text-ink">{unread}</span>}</NavLink>
      <NavLink to="/inicio" className={link} onClick={() => setOpen(false)}>Inicio</NavLink>
      <NavLink to="/editores" className={link} onClick={() => setOpen(false)}>Explorar</NavLink>
      {user && <NavLink to="/panel" className={link} onClick={() => setOpen(false)}>Mi panel</NavLink>}
      {isAdmin && <NavLink to="/admin" className={link} onClick={() => setOpen(false)}>Admin</NavLink>}
    </>
  );

  return (
    <div className="flex min-h-screen flex-col">
      <InAppNotice />
      <header className="sticky top-0 z-40 border-b border-line bg-ink/85 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-4 px-4">
          <Logo />
          <nav className="ml-4 hidden items-center gap-1 md:flex" aria-label="Principal">{nav}</nav>
          <div className="ml-auto flex items-center gap-2">
            {user ? (
              <>
                <AccountMenu me={me} name={user.displayName ?? ""} onSignOut={() => void signOut()} />
              </>
            ) : (
              <button type="button" className="btn-primary" onClick={() => void signIn()}>Iniciar sesión</button>
            )}
            <button
              type="button"
              className="rounded-lg p-2 text-mute hover:text-white md:hidden"
              aria-label={open ? "Cerrar menú" : "Abrir menú"}
              aria-expanded={open}
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
        {open && (
          <nav className="flex flex-col gap-1 border-t border-line px-4 py-3 md:hidden" aria-label="Principal móvil">
            {nav}
            {user && (
              <button type="button" className="rounded-lg px-3 py-2 text-left text-sm font-medium text-mute hover:text-white" onClick={() => void signOut()}>
                Salir
              </button>
            )}
          </nav>
        )}
      </header>

      <main className={cx("mx-auto w-full max-w-6xl flex-1", inChat ? cx("h-[calc(100dvh-4rem)] sm:p-4", showTabs && "max-md:h-[calc(100dvh-4rem-4.25rem)]") : "px-4 py-8 pb-24 md:pb-8")}>
        <div key={pathname} className={cx("animate-fade", inChat && "h-full")}>
          <Outlet />
        </div>
      </main>

      <footer className={cx("border-t border-line", inChat && "hidden")}>
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-6 text-sm text-mute sm:flex-row sm:items-center sm:justify-between">
          <p>Una comunidad para conectar, compartir tu trabajo y conversar.</p>
          <p className="flex gap-4">
            <Link to="/privacidad" className="hover:text-white">Privacidad</Link>
            <Link to="/terminos" className="hover:text-white">Términos</Link>
          </p>
        </div>
      </footer>

      {showTabs && (
        <nav aria-label="Navegación móvil" className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-ink/90 pb-[env(safe-area-inset-bottom)] backdrop-blur-md md:hidden">
          <div className="grid grid-cols-4">
            {TABS.map(([to, label, Icon]) => (
              <NavLink key={to} to={to} className={({ isActive }) => cx("relative flex flex-col items-center gap-0.5 py-2 text-[11px] font-medium transition", isActive ? "text-neon" : "text-mute")}>
                <Icon className="h-5 w-5" />
                {label}
                {to === "/mensajes" && unread > 0 && <span className="absolute right-[28%] top-1 rounded-full bg-neon px-1.5 text-[10px] font-bold text-ink">{unread}</span>}
              </NavLink>
            ))}
          </div>
        </nav>
      )}
    </div>
  );
}
