import type { ReactNode } from "react";

/** Niveles de avatares: cuántos seguidores hacen falta para usarlos. */
export type Tier = "base" | "pro" | "elite";
export const TIER_MIN: Record<Tier, number> = { base: 0, pro: 20, elite: 500 };
export const TIER_LABEL: Record<Tier, string> = { base: "Básicos", pro: "Pro", elite: "Élite" };

export interface AvatarDef {
  id: string;
  name: string;
  tier: Tier;
}

type Creature = "zorro" | "gato" | "robot" | "alien" | "panda" | "fantasma";
type Extra = "gafas" | "auri" | "visor" | "redondas" | "bandana" | "corona" | "aureola" | "estrellas";

const INK = "#14121F";
const GOLD = "#FFC83D";
const GOLD_DARK = "#B7791F";

/** Altura de los ojos de cada personaje (para colocar gafas y visores). */
const EYE_Y: Record<Creature, number> = { zorro: 54, gato: 54, robot: 47, alien: 50, panda: 53, fantasma: 48 };

function body(c: Creature): ReactNode {
  switch (c) {
    case "zorro":
      return (
        <>
          <path d="M18 20 L44 40 L16 54Z" fill="#F97316" />
          <path d="M82 20 L56 40 L84 54Z" fill="#F97316" />
          <path d="M24 28 L38 40 L24 48Z" fill="#7C2D12" />
          <path d="M76 28 L62 40 L76 48Z" fill="#7C2D12" />
          <ellipse cx="50" cy="58" rx="31" ry="26" fill="#F97316" />
          <path d="M19 62 Q34 58 50 70 Q66 58 81 62 Q70 88 50 88 Q30 88 19 62Z" fill="#FFF7ED" />
          <circle cx="38" cy="54" r="3.6" fill={INK} />
          <circle cx="62" cy="54" r="3.6" fill={INK} />
          <ellipse cx="50" cy="70" rx="4.5" ry="3.2" fill={INK} />
        </>
      );
    case "gato":
      return (
        <>
          <path d="M20 44 L24 12 L47 32Z" fill="#94A3B8" />
          <path d="M80 44 L76 12 L53 32Z" fill="#94A3B8" />
          <path d="M26 36 L27 21 L38 31Z" fill="#F9A8D4" />
          <path d="M74 36 L73 21 L62 31Z" fill="#F9A8D4" />
          <ellipse cx="50" cy="58" rx="31" ry="26" fill="#94A3B8" />
          <ellipse cx="38" cy="54" rx="5" ry="6" fill="#FDE68A" />
          <ellipse cx="62" cy="54" rx="5" ry="6" fill="#FDE68A" />
          <ellipse cx="38" cy="54" rx="1.8" ry="5" fill={INK} />
          <ellipse cx="62" cy="54" rx="1.8" ry="5" fill={INK} />
          <path d="M46 66 L54 66 L50 71Z" fill="#F472B6" />
          <path d="M50 71 Q45 77 40 74 M50 71 Q55 77 60 74" stroke={INK} strokeWidth="1.8" fill="none" strokeLinecap="round" />
          <path d="M14 62 L32 66 M14 72 L32 70 M86 62 L68 66 M86 72 L68 70" stroke="#E2E8F0" strokeWidth="1.6" strokeLinecap="round" />
        </>
      );
    case "robot":
      return (
        <>
          <path d="M50 28 V14" stroke="#64748B" strokeWidth="3" strokeLinecap="round" />
          <circle cx="50" cy="12" r="5" fill="#F43F5E" />
          <rect x="12" y="44" width="9" height="20" rx="4" fill="#64748B" />
          <rect x="79" y="44" width="9" height="20" rx="4" fill="#64748B" />
          <rect x="20" y="28" width="60" height="52" rx="14" fill="#CBD5E1" />
          <rect x="27" y="38" width="46" height="22" rx="9" fill={INK} />
          <circle cx="40" cy="49" r="5" fill="#22D3EE" />
          <circle cx="60" cy="49" r="5" fill="#22D3EE" />
          <rect x="36" y="67" width="28" height="7" rx="3.5" fill="#64748B" />
          <path d="M43 67 V74 M50 67 V74 M57 67 V74" stroke="#CBD5E1" strokeWidth="1.5" />
        </>
      );
    case "alien":
      return (
        <>
          <path d="M36 22 Q30 10 24 10 M64 22 Q70 10 76 10" stroke="#16A34A" strokeWidth="3" fill="none" strokeLinecap="round" />
          <circle cx="24" cy="10" r="4" fill="#BEF264" />
          <circle cx="76" cy="10" r="4" fill="#BEF264" />
          <path d="M50 20 C78 20 84 46 72 68 C64 82 36 82 28 68 C16 46 22 20 50 20Z" fill="#4ADE80" />
          <ellipse cx="37" cy="50" rx="8" ry="12" transform="rotate(-20 37 50)" fill={INK} />
          <ellipse cx="63" cy="50" rx="8" ry="12" transform="rotate(20 63 50)" fill={INK} />
          <circle cx="40" cy="46" r="2.2" fill="#fff" />
          <circle cx="66" cy="46" r="2.2" fill="#fff" />
          <path d="M43 72 Q50 77 57 72" stroke={INK} strokeWidth="2" fill="none" strokeLinecap="round" />
        </>
      );
    case "panda":
      return (
        <>
          <circle cx="25" cy="27" r="11" fill={INK} />
          <circle cx="75" cy="27" r="11" fill={INK} />
          <circle cx="50" cy="57" r="31" fill="#F8FAFC" />
          <ellipse cx="36" cy="53" rx="8" ry="11" transform="rotate(25 36 53)" fill={INK} />
          <ellipse cx="64" cy="53" rx="8" ry="11" transform="rotate(-25 64 53)" fill={INK} />
          <circle cx="37" cy="52" r="2.6" fill="#fff" />
          <circle cx="63" cy="52" r="2.6" fill="#fff" />
          <ellipse cx="50" cy="68" rx="5" ry="3.6" fill={INK} />
          <path d="M44 75 Q50 80 56 75" stroke={INK} strokeWidth="2" fill="none" strokeLinecap="round" />
        </>
      );
    case "fantasma":
      return (
        <>
          <path d="M20 84 V48 A30 30 0 0 1 80 48 V84 L70 76 L60 84 L50 76 L40 84 L30 76Z" fill="#F1F5F9" />
          <ellipse cx="39" cy="48" rx="5" ry="7" fill={INK} />
          <ellipse cx="61" cy="48" rx="5" ry="7" fill={INK} />
          <ellipse cx="50" cy="64" rx="5" ry="6" fill={INK} />
          <ellipse cx="29" cy="58" rx="5" ry="3" fill="#FBCFE8" />
          <ellipse cx="71" cy="58" rx="5" ry="3" fill="#FBCFE8" />
        </>
      );
  }
}

function extra(e: Extra | undefined, c: Creature): ReactNode {
  const y = EYE_Y[c];
  switch (e) {
    case "gafas":
      return (
        <>
          <rect x="24" y={y - 7} width="23" height="14" rx="5" fill={INK} />
          <rect x="53" y={y - 7} width="23" height="14" rx="5" fill={INK} />
          <path d={`M47 ${y - 2} H53`} stroke={INK} strokeWidth="3" />
          <path d={`M28 ${y - 4} l6 0 M57 ${y - 4} l6 0`} stroke="#fff" strokeWidth="1.6" strokeLinecap="round" opacity=".7" />
        </>
      );
    case "redondas":
      return (
        <>
          <circle cx="38" cy={y} r="9" fill="#fff" fillOpacity=".25" stroke="#F59E0B" strokeWidth="2.6" />
          <circle cx="62" cy={y} r="9" fill="#fff" fillOpacity=".25" stroke="#F59E0B" strokeWidth="2.6" />
          <path d={`M47 ${y} H53`} stroke="#F59E0B" strokeWidth="2.6" />
        </>
      );
    case "visor":
      return (
        <>
          <rect x="20" y={y - 9} width="60" height="18" rx="9" fill="#22D3EE" opacity=".92" />
          <rect x="24" y={y - 6} width="52" height="5" rx="2.5" fill="#fff" opacity=".55" />
        </>
      );
    case "auri":
      return (
        <>
          <path d="M16 56 A34 34 0 0 1 84 56" stroke="#8B5CFF" strokeWidth="5" fill="none" strokeLinecap="round" />
          <rect x="9" y="48" width="12" height="22" rx="6" fill="#8B5CFF" />
          <rect x="79" y="48" width="12" height="22" rx="6" fill="#8B5CFF" />
          <rect x="12" y="52" width="6" height="14" rx="3" fill="#C6FF3D" />
          <rect x="82" y="52" width="6" height="14" rx="3" fill="#C6FF3D" />
        </>
      );
    case "bandana":
      return (
        <>
          <path d="M20 40 Q50 26 80 40 L80 49 Q50 36 20 49Z" fill="#EF4444" />
          <circle cx="40" cy="40" r="1.8" fill="#fff" />
          <circle cx="52" cy="37" r="1.8" fill="#fff" />
          <circle cx="64" cy="40" r="1.8" fill="#fff" />
          <path d="M80 42 L92 36 L90 50Z" fill="#EF4444" />
        </>
      );
    case "corona":
      return (
        <>
          <path d="M30 22 L33 6 L42 15 L50 3 L58 15 L67 6 L70 22Z" fill={GOLD} stroke={GOLD_DARK} strokeWidth="2" strokeLinejoin="round" />
          <circle cx="50" cy="12" r="2.4" fill="#EF4444" />
        </>
      );
    case "aureola":
      return <ellipse cx="50" cy="8" rx="17" ry="5" fill="none" stroke={GOLD} strokeWidth="3.5" />;
    case "estrellas":
      return (
        <>
          <path d="M50 2 L52 8 L58 10 L52 12 L50 18 L48 12 L42 10 L48 8Z" fill={GOLD} />
          <path d="M30 8 L31.2 11 L34 12 L31.2 13 L30 16 L28.8 13 L26 12 L28.8 11Z" fill="#FDE68A" />
          <path d="M70 8 L71.2 11 L74 12 L71.2 13 L70 16 L68.8 13 L66 12 L68.8 11Z" fill="#FDE68A" />
        </>
      );
    default:
      return null;
  }
}

interface Def extends AvatarDef {
  c: Creature;
  x?: Extra;
  bg: [string, string];
}

const DEFS: Def[] = [
  // Básicos: para todos.
  { id: "zorro", name: "Zorro", tier: "base", c: "zorro", bg: ["#FDBA74", "#FB923C"] },
  { id: "gato", name: "Gato", tier: "base", c: "gato", bg: ["#C4B5FD", "#8B5CF6"] },
  { id: "robot", name: "Robot", tier: "base", c: "robot", bg: ["#7DD3FC", "#38BDF8"] },
  { id: "alien", name: "Alien", tier: "base", c: "alien", bg: ["#FDE68A", "#FBBF24"] },
  { id: "panda", name: "Panda", tier: "base", c: "panda", bg: ["#86EFAC", "#34D399"] },
  { id: "fantasma", name: "Fantasma", tier: "base", c: "fantasma", bg: ["#FBCFE8", "#F472B6"] },
  // Pro: 20 seguidores.
  { id: "zorro-pro", name: "Zorro cool", tier: "pro", c: "zorro", x: "gafas", bg: ["#8B5CFF", "#C6FF3D"] },
  { id: "gato-pro", name: "Gato DJ", tier: "pro", c: "gato", x: "auri", bg: ["#FF4D6D", "#FFB347"] },
  { id: "robot-pro", name: "Robot cyber", tier: "pro", c: "robot", x: "visor", bg: ["#00D1FF", "#8B5CFF"] },
  { id: "alien-pro", name: "Alien gamer", tier: "pro", c: "alien", x: "auri", bg: ["#00E58F", "#00A3FF"] },
  { id: "panda-pro", name: "Panda ninja", tier: "pro", c: "panda", x: "bandana", bg: ["#FF5CF4", "#7A5CFF"] },
  { id: "fantasma-pro", name: "Fantasma nerd", tier: "pro", c: "fantasma", x: "redondas", bg: ["#22D3EE", "#6366F1"] },
  // Élite: 500 seguidores.
  { id: "zorro-elite", name: "Zorro rey", tier: "elite", c: "zorro", x: "corona", bg: ["#3B1F04", "#7A4B0C"] },
  { id: "gato-elite", name: "Gato divino", tier: "elite", c: "gato", x: "aureola", bg: ["#1E1B4B", "#4C1D95"] },
  { id: "robot-elite", name: "Robot emperador", tier: "elite", c: "robot", x: "corona", bg: ["#0F172A", "#1E3A5F"] },
  { id: "alien-elite", name: "Alien estelar", tier: "elite", c: "alien", x: "estrellas", bg: ["#052E16", "#14532D"] },
  { id: "panda-elite", name: "Panda emperador", tier: "elite", c: "panda", x: "corona", bg: ["#450A0A", "#7F1D1D"] },
  { id: "fantasma-elite", name: "Fantasma sagrado", tier: "elite", c: "fantasma", x: "aureola", bg: ["#2E1065", "#581C87"] },
];

export const AVATARS: AvatarDef[] = DEFS.map(({ id, name, tier }) => ({ id, name, tier }));
const BY_ID = new Map(DEFS.map((d) => [d.id, d]));

export const isAvatarId = (v: unknown): v is string => typeof v === "string" && BY_ID.has(v);

/** Si con esa cantidad de seguidores (o siendo admin) se puede usar un nivel de avatares. */
export const tierUnlocked = (tier: Tier, followers: number, isAdmin = false): boolean => isAdmin || followers >= TIER_MIN[tier];

/** Dibuja un avatar en un cuadrado; el círculo lo recorta quien lo usa. */
export function AvatarArt({ id, size }: { id: string; size: number }) {
  const d = BY_ID.get(id);
  if (!d) return null;
  const elite = d.tier === "elite";
  const gid = `av-${d.id}`;
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" role="img" aria-label={d.name} className="block h-full w-full">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={d.bg[0]} />
          <stop offset="1" stopColor={d.bg[1]} />
        </linearGradient>
      </defs>
      <rect width="100" height="100" fill={`url(#${gid})`} />
      <g transform={elite ? "translate(9 13) scale(.82)" : undefined}>
        {body(d.c)}
        {d.tier === "pro" && extra(d.x, d.c)}
      </g>
      {elite && extra(d.x, d.c)}
      {elite && (
        <>
          <circle cx="50" cy="50" r="46" fill="none" stroke={GOLD} strokeWidth="3.5" />
          <path d="M14 78 L15.4 81.6 L19 83 L15.4 84.4 L14 88 L12.6 84.4 L9 83 L12.6 81.6Z" fill="#FDE68A" />
          <path d="M86 66 L87.2 69 L90 70 L87.2 71 L86 74 L84.8 71 L82 70 L84.8 69Z" fill="#FDE68A" />
        </>
      )}
    </svg>
  );
}
