import type { Timestamp } from "firebase/firestore";

export const tsMs = (t?: Timestamp | null): number =>
  t && typeof t.toMillis === "function" ? t.toMillis() : 0;

export const hhmm = (t?: Timestamp | null): string =>
  new Date(tsMs(t) || Date.now()).toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" });

/** Solo acepta imágenes alojadas en Firebase Storage. */
export const okImg = (u: unknown): u is string =>
  typeof u === "string" && u.startsWith("https://firebasestorage.googleapis.com/");

/** Limpia un usuario de red social: acepta @usuario, enlaces o texto suelto. */
export function handle(s?: string): string {
  return (s || "")
    .trim()
    .replace(/^https?:\/\/[^\s]*\//, "")
    .replace(/[?#].*$/, "")
    .replace(/^@/, "")
    .replace(/[^\w.\-]/g, "");
}

export const initial = (name?: string): string => (name || "?").trim().charAt(0).toUpperCase() || "?";

/** Navegadores internos de TikTok, Instagram, Facebook, etc. Google bloquea el login ahí. */
export function isInAppBrowser(): boolean {
  if (typeof navigator === "undefined") return false;
  return /FBAN|FBAV|Instagram|musical_ly|TikTok|BytedanceWebview|Snapchat|Twitter|; wv\)/i.test(navigator.userAgent);
}

export function beep(): void {
  try {
    if (localStorage.getItem("z166.sound") === "0") return;
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const a = new Ctx();
    const o = a.createOscillator();
    const g = a.createGain();
    o.connect(g);
    g.connect(a.destination);
    o.frequency.value = 880;
    g.gain.value = 0.05;
    o.start();
    o.stop(a.currentTime + 0.12);
  } catch {
    /* sin audio: no pasa nada */
  }
}

/** Quita las propiedades undefined (Firestore no las acepta). */
export function compact<T extends Record<string, unknown>>(o: T): T {
  return Object.fromEntries(Object.entries(o).filter(([, v]) => v !== undefined)) as T;
}

export const cx = (...c: Array<string | false | null | undefined>): string => c.filter(Boolean).join(" ");
