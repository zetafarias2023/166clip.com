/** Convierte un error de Firebase en un mensaje que se entienda. */
export function explain(e: unknown, fallback = "No se pudo guardar."): string {
  const code = (e as { code?: string })?.code ?? "";
  if (code.includes("permission-denied") || code.includes("unauthorized"))
    return "Firebase rechazó el guardado: falta publicar las reglas nuevas (Firestore y Storage) o no tenés permiso.";
  if (code.includes("unauthenticated")) return "Iniciá sesión de nuevo.";
  if (code.includes("unavailable") || code.includes("network")) return "Sin conexión. Probá de nuevo.";
  return code ? `${fallback} (${code})` : fallback;
}
