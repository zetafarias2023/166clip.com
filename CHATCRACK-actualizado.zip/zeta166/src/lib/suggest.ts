import type { Profile } from "../types";

/** Sugerencias: primero los verificados, y dentro de cada grupo los que tienen más seguidores. */
export function suggest(
  profiles: Profile[],
  verified: Set<string>,
  followers: Map<string, number>,
  skip: Set<string>,
): Profile[] {
  return profiles
    .filter((p) => !skip.has(p.id))
    .sort(
      (a, b) =>
        Number(verified.has(b.id)) - Number(verified.has(a.id)) || (followers.get(b.id) ?? 0) - (followers.get(a.id) ?? 0),
    );
}
