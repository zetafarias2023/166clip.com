import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { Link, Navigate, useNavigate, useParams } from "react-router-dom";
import { Archive, Ban, Bell, BellOff, Check, CheckCheck, ChevronLeft, Copy, CornerUpLeft, Mic, MessageSquarePlus, MoreHorizontal, Phone, Send, Smile, Square, Star, Trash2, X } from "lucide-react";
import { Modal } from "../components/Modal";
import { Avatar, VerifiedBadge } from "../components/Avatar";
import { EmptyState } from "../components/EmptyState";
import { Lightbox } from "../components/Lightbox";
import { useAuth } from "../hooks/useAuth";
import { useChat } from "../hooks/useChat";
import { useData, useProfile } from "../hooks/useData";
import { useLists } from "../hooks/useLists";
import { suggest } from "../lib/suggest";
import { useSignIn } from "../hooks/useSignIn";
import { useToast } from "../hooks/useToast";
import { cx, hhmm, okImg, tsMs } from "../lib/utils";
import { clearConversation, convId, deleteMessage, markSeen, reactToMessage, sendMessage, setTyping, subscribeMessages, subscribePresence } from "../services/chat";
import { useCall } from "../hooks/useCall";
import { registerPush } from "../services/push";
import { explain } from "../lib/errors";
import { uploadAudio } from "../services/storage";
import type { Message } from "../types";

/** Nota de voz con aviso si el navegador no la puede reproducir. */
function VoiceNote({ src }: { src: string }) {
  const [bad, setBad] = useState(false);
  if (bad) {
    return <a href={src} target="_blank" rel="noopener noreferrer" className="text-sm text-neon underline">Tu navegador no puede reproducir este audio. Abrirlo</a>;
  }
  return (
    <audio controls preload="metadata" src={src} className="h-10 w-56 max-w-full" onError={() => setBad(true)}>
      <track kind="captions" />
    </audio>
  );
}

function dayLabel(ms: number): string {
  const d = new Date(ms);
  const t = new Date();
  if (d.toDateString() === t.toDateString()) return "Hoy";
  t.setDate(t.getDate() - 1);
  if (d.toDateString() === t.toDateString()) return "Ayer";
  return d.toLocaleDateString("es-AR", { day: "numeric", month: "long" });
}

export default function Messages() {
  const { otherId } = useParams();
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const signIn = useSignIn();
  const { push } = useToast();
  const { convs, isUnread, setActiveChat } = useChat();
  const { profiles, verified, followers } = useData();
  const { lists, toggle } = useLists();
  const { profile: other, loading: otherLoading } = useProfile(otherId);

  const [msgs, setMsgs] = useState<Message[]>([]);
  const [text, setText] = useState("");
  const [search, setSearch] = useState("");
  const [sending, setSending] = useState(false);
  const [picker, setPicker] = useState(false);
  const [emojis, setEmojis] = useState(false);
  const [people, setPeople] = useState("");
  const [tab, setTab] = useState<"todos" | "fav" | "close" | "archived">("todos");
  const { startCall } = useCall();
  const [rec, setRec] = useState<MediaRecorder | null>(null);
  const [secs, setSecs] = useState(0);
  const [sheet, setSheet] = useState<Message | null>(null);
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const [seenAt, setSeenAt] = useState(0);
  const [now, setNow] = useState(Date.now());
  const typingSent = useRef(0);
  const chunks = useRef<Blob[]>([]);
  const timer = useRef(0);
  const [zoom, setZoom] = useState<string | null>(null);
  const [confirm, setConfirm] = useState<null | { kind: "msg"; id: string } | { kind: "conv" }>(null);
  const [perm, setPerm] = useState<NotificationPermission | "none">(
    typeof Notification === "undefined" ? "none" : Notification.permission,
  );
  const endRef = useRef<HTMLDivElement>(null);

  const uid = user?.uid;
  const cid = uid && otherId ? convId(uid, otherId) : null;
  const conv = convs.find((c) => c.id === cid);
  const me = profiles.find((p) => p.id === uid);
  const clearedAt = tsMs(conv?.cleared?.[uid ?? ""]);
  const myName = me?.name || user?.displayName || "Usuario";
  const otherName = other?.name || conv?.names?.[otherId ?? ""] || "Usuario";

  useEffect(() => {
    setActiveChat(cid);
    return () => setActiveChat(null);
  }, [cid, setActiveChat]);

  useEffect(() => {
    setMsgs([]);
    if (!cid) return;
    return subscribeMessages(cid, setMsgs);
  }, [cid]);

  useEffect(() => {
    setSeenAt(0);
    setReplyTo(null);
    if (!otherId) return;
    return subscribePresence(otherId, setSeenAt);
  }, [otherId]);

  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), 2000);
    return () => window.clearInterval(t);
  }, []);

  const last = msgs[msgs.length - 1];
  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [msgs.length, cid]);

  // Marca "visto" cuando llega un mensaje de la otra persona y la pestaña está a la vista.
  useEffect(() => {
    if (!cid || !uid || !last || last.from === uid) return;
    const go = () => {
      if (!document.hidden) markSeen(cid, uid).catch(() => undefined);
    };
    go();
    document.addEventListener("visibilitychange", go);
    return () => document.removeEventListener("visibilitychange", go);
  }, [cid, uid, last?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const inbox = useMemo(() => {
    const t = search.trim().toLowerCase();
    return [...convs]
      .sort((a, b) => tsMs(b.lastAt) - tsMs(a.lastAt))
      .map((c) => {
        const o = c.participants.find((p) => p !== uid) ?? "";
        return { c, o, name: profiles.find((p) => p.id === o)?.name || c.names?.[o] || "Usuario" };
      })
      .filter((r) => tsMs(r.c.lastAt) > tsMs(r.c.cleared?.[uid ?? ""]))
      .filter((r) => !lists.blocked.includes(r.o))
      .filter((r) => (tab === "archived" ? lists.archived.includes(r.o) : !lists.archived.includes(r.o)))
      .filter((r) => (tab === "fav" ? lists.fav.includes(r.o) : tab === "close" ? lists.close.includes(r.o) : true))
      .filter((r) => !t || r.name.toLowerCase().includes(t));
  }, [convs, profiles, uid, search, lists, tab]);

  if (authLoading) return null;
  if (!user) {
    return (
      <EmptyState title="Iniciá sesión para ver tus mensajes">
        <button type="button" className="btn-primary mt-3" onClick={() => void signIn()}>Iniciar sesión con Google</button>
      </EmptyState>
    );
  }
  if (otherId === user.uid) return <Navigate to="/mensajes" replace />;

  const submit = async (payload: { text?: string; img?: string }) => {
    if (!otherId) return;
    setSending(true);
    try {
      const reply = replyTo ? { id: replyTo.id, from: replyTo.from, text: (replyTo.text ?? (replyTo.img ? "📷 Foto" : "🎤 Audio")).slice(0, 80) } : undefined;
      await sendMessage({ uid: user.uid, name: myName }, { uid: otherId, name: otherName }, { ...payload, ...(reply ? { reply } : {}) });
      if (payload.text !== undefined) setText("");
      setReplyTo(null);
    } catch (e) {
      const code = (e as { code?: string }).code ?? "";
      push(code.includes("permission") ? "No se pudo enviar. Puede que esa persona te haya bloqueado o que falte publicar las reglas de Firebase." : explain(e, "No se pudo enviar el mensaje."), { tone: "error" });
    } finally {
      setSending(false);
    }
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (text.trim()) void submit({ text: text.trim() });
  };

  const sendAudio = async (blob: Blob, dur: number) => {
    if (!otherId) return;
    setSending(true);
    try {
      const url = await uploadAudio(user.uid, blob);
      await sendMessage({ uid: user.uid, name: myName }, { uid: otherId, name: otherName }, { aud: url, dur });
    } catch (e) {
      push(explain(e, "No se pudo enviar el audio."), { tone: "error" });
      console.error("audio", e);
    } finally {
      setSending(false);
    }
  };

  const startRec = async () => {
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      return push("Tu navegador no puede grabar audio.", { tone: "error" });
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // Se prefiere MP4/AAC (suena en todos los navegadores); si no se puede, WebM u OGG.
      const mime = ["audio/mp4", "audio/webm;codecs=opus", "audio/webm", "audio/ogg;codecs=opus"].find((t) => MediaRecorder.isTypeSupported?.(t));
      const mr = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
      const t0 = Date.now();
      chunks.current = [];
      mr.ondataavailable = (e) => {
        if (e.data.size) chunks.current.push(e.data);
      };
      mr.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        window.clearInterval(timer.current);
        setRec(null);
        const dur = Math.round((Date.now() - t0) / 1000);
        if (dur >= 1) void sendAudio(new Blob(chunks.current, { type: mr.mimeType || "audio/webm" }), dur);
      };
      mr.start();
      setRec(mr);
      setSecs(0);
      timer.current = window.setInterval(() => setSecs((s) => s + 1), 1000);
      window.setTimeout(() => mr.state === "recording" && mr.stop(), 120000);
    } catch {
      push("No se pudo usar el micrófono. Revisá el permiso del navegador.", { tone: "error" });
    }
  };

  const tg = (key: "fav" | "archived" | "muted" | "blocked", msg: [string, string]) => {
    if (!otherId) return;
    const on = !lists[key].includes(otherId);
    toggle(key, otherId, on)
      .then(() => {
        push(on ? msg[0] : msg[1], { tone: "ok" });
        if (key === "archived" && on) navigate("/mensajes");
      })
      .catch((e) => push(explain(e), { tone: "error" }));
  };

  const doReact = async (m: Message, emoji: string) => {
    setSheet(null);
    if (!cid) return;
    try {
      await reactToMessage(cid, m.id, user.uid, m.react?.[user.uid] === emoji ? null : emoji);
    } catch (e) {
      push(explain(e, "No se pudo reaccionar."), { tone: "error" });
    }
  };

  const enableNotifications = async () => {
    if (typeof Notification === "undefined") return push("Tu navegador no soporta avisos.", { tone: "error" });
    const r = await Notification.requestPermission();
    setPerm(r);
    if (r === "granted") void registerPush(user.uid);
  };

  const shown = msgs.filter((m) => tsMs(m.at) > clearedAt);
  const doConfirm = async () => {
    const c = confirm;
    setConfirm(null);
    if (!c || !cid) return;
    try {
      if (c.kind === "msg") await deleteMessage(cid, c.id);
      else {
        await clearConversation(cid, user.uid);
        navigate("/mensajes");
      }
    } catch (e) {
      push(explain(e, "No se pudo eliminar."), { tone: "error" });
    }
  };
  const seenByOther = tsMs(conv?.seen?.[otherId ?? ""]);
  const typingNow = tsMs(conv?.typing?.[otherId ?? ""]) > now - 5000;
  const online = seenAt > 0 && now - seenAt < 90000;
  const status = typingNow
    ? "escribiendo…"
    : online
      ? "en línea"
      : seenAt
        ? `últ. vez ${new Date(seenAt).toDateString() === new Date().toDateString() ? "hoy" : new Date(seenAt).toLocaleDateString("es-AR", { day: "numeric", month: "short" })} ${new Date(seenAt).toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" })}`
        : "";

  return (
    <div className="flex h-full flex-col">
      <div className={cx("flex flex-wrap items-center justify-between gap-2 px-3 py-2 sm:mb-3 sm:px-0 sm:py-0", otherId && "hidden lg:flex")}>
        <h1 className="font-display text-2xl font-bold">Chats</h1>
        {perm !== "none" && (
          <button type="button" className="btn-ghost" disabled={perm !== "default"} onClick={() => void enableNotifications()}>
            <Bell className="h-4 w-4" />
            {perm === "granted" ? "Avisos activados" : perm === "denied" ? "Avisos bloqueados" : "Activar avisos"}
          </button>
        )}
      </div>

      <div className="grid min-h-0 flex-1 overflow-hidden bg-surface sm:rounded-2xl sm:border sm:border-line lg:grid-cols-[340px_1fr]">
        <section className={cx("min-h-0 flex-col border-line lg:flex lg:border-r", otherId ? "hidden" : "flex")} aria-label="Conversaciones">
          <div className="flex items-center gap-2 border-b border-line p-3">
            <label htmlFor="chat-search" className="sr-only">Buscar conversación</label>
            <input id="chat-search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar conversación" className="input" />
            <button type="button" className="btn-primary !px-3" onClick={() => setPicker(true)} aria-label="Nuevo chat" title="Nuevo chat"><MessageSquarePlus className="h-5 w-5" /></button>
          </div>
          <div className="flex gap-2 overflow-x-auto border-b border-line px-3 py-2">
            {([["todos", "Todos"], ["fav", "Favoritos"], ["close", "Mejores amigos"], ["archived", "Archivados"]] as const).map(([k, l]) => (
              <button key={k} type="button" onClick={() => setTab(k)} className={cx("chip shrink-0 !py-1 text-xs", tab === k && "chip-on")}>{l}</button>
            ))}
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto">
            {inbox.map(({ c, o, name }) => {
              const unread = isUnread(c);
              return (
                <Link
                  key={c.id}
                  to={`/mensajes/${o}`}
                  className={cx("flex items-center gap-3 px-3 py-3 transition hover:bg-raise", c.id === cid && "bg-raise")}
                >
                  <Avatar profile={profiles.find((p) => p.id === o)} name={name} size={40} />
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-1 truncate font-medium">
                      <span className="truncate">{name}</span>
                      {verified.has(o) && <VerifiedBadge />}
                    </p>
                    <p className={cx("truncate text-sm", unread ? "font-bold text-white" : "text-mute")}>
                      {c.lastFrom === uid ? "Vos: " : ""}
                      {c.lastText}
                    </p>
                  </div>
                  {unread && <span className="h-2.5 w-2.5 rounded-full bg-neon" aria-label="Sin leer" />}
                </Link>
              );
            })}
            {!inbox.length && (
              <p className="p-4 text-sm text-mute">
                {convs.length
                  ? "Sin resultados."
                  : "Todavía no tenés chats. Entrá al perfil de un editor y tocá Enviar mensaje."}
              </p>
            )}
          </div>
        </section>

        <section className={cx("min-h-0 flex-col lg:flex", otherId ? "flex" : "hidden")} aria-label="Conversación">
          {!otherId ? (
            <p className="m-auto p-6 text-mute">Elegí una conversación para empezar.</p>
          ) : !other && !otherLoading && !conv ? (
            <div className="m-auto p-6 text-center text-mute">
              Este editor ya no existe. <Link to="/mensajes" className="text-neon hover:underline">Volver</Link>
            </div>
          ) : (
            <>
              <header className="flex items-center gap-3 border-b border-line p-3">
                <button type="button" onClick={() => navigate("/mensajes")} className="rounded-lg p-1 text-mute hover:text-white lg:hidden" aria-label="Volver a las conversaciones">
                  <ChevronLeft className="h-6 w-6" />
                </button>
                <Avatar profile={other} name={otherName} size={36} />
                <div className="min-w-0 flex-1">
                  <p className="flex items-center gap-1 font-display text-lg font-semibold leading-tight">
                    <span className="truncate">{otherName}</span>
                    {verified.has(otherId) && <VerifiedBadge />}
                  </p>
                  {status && <p className={cx("truncate text-xs", typingNow || online ? "text-neon" : "text-mute")}>{status}</p>}
                </div>
                {other && <Link to={`/editor/${otherId}`} className="btn-ghost hidden !py-1.5 sm:inline-flex">Perfil</Link>}
                <button type="button" className="btn-ghost !px-2 !py-1.5" onClick={() => void startCall(otherId, otherName)} aria-label="Llamar" title="Llamada de voz"><Phone className="h-4 w-4" /></button>
                <button type="button" className={cx("btn-ghost !px-2 !py-1.5", lists.fav.includes(otherId) && "!text-neon")} onClick={() => tg("fav", ["Agregado a favoritos.", "Quitado de favoritos."])} aria-label="Favorito" title="Favorito"><Star className="h-4 w-4" /></button>
                <button type="button" className={cx("btn-ghost !px-2 !py-1.5", lists.muted.includes(otherId) && "!text-neon")} onClick={() => tg("muted", ["Chat silenciado.", "Chat con avisos otra vez."])} aria-label="Silenciar" title="Silenciar"><BellOff className="h-4 w-4" /></button>
                <button type="button" className="btn-ghost !px-2 !py-1.5" onClick={() => tg("archived", ["Chat archivado.", "Chat desarchivado."])} aria-label="Archivar" title="Archivar"><Archive className="h-4 w-4" /></button>
                <button type="button" className="btn-ghost !px-2 !py-1.5 hover:!text-danger" onClick={() => tg("blocked", ["Persona bloqueada.", "Persona desbloqueada."])} aria-label="Bloquear" title="Bloquear"><Ban className="h-4 w-4" /></button>
                <button type="button" className="btn-ghost !px-2 !py-1.5" onClick={() => setConfirm({ kind: "conv" })} aria-label="Eliminar chat" title="Eliminar chat">
                  <Trash2 className="h-4 w-4" />
                </button>
              </header>

              <div className="chat-bg min-h-0 flex-1 overflow-y-auto p-4">
                {!shown.length && <p className="text-sm text-mute">Todavía no hay mensajes. Escribí el primero.</p>}
                {shown.map((m, i) => {
                  const mine = m.from === user.uid;
                  const prev = shown[i - 1];
                  const day = new Date(tsMs(m.at) || Date.now()).toDateString();
                  const newDay = !prev || new Date(tsMs(prev.at) || Date.now()).toDateString() !== day;
                  const tail = !prev || prev.from !== m.from || newDay;
                  return (
                    <div key={m.id}>
                      {newDay && (
                        <p className="my-3 text-center"><span className="rounded-full border border-line bg-ink px-3 py-1 text-xs text-mute">{dayLabel(tsMs(m.at) || Date.now())}</span></p>
                      )}
                    <div className={cx("flex", mine && "justify-end", tail ? "mt-2" : "mt-0.5")}>
                      <div className={cx("max-w-[82%] rounded-2xl px-3.5 py-2 text-sm shadow-sm", mine ? "bg-gradient-to-br from-violet to-[#6A35E0] text-white" : "border border-line bg-raise", tail && (mine ? "rounded-tr-sm" : "rounded-tl-sm"))}>
                        {m.reply && (
                          <div className="mb-1 rounded-lg border-l-2 border-neon bg-black/25 px-2 py-1 text-xs">
                            <p className="font-medium text-neon">{m.reply.from === user.uid ? "Vos" : otherName}</p>
                            <p className="truncate opacity-80">{m.reply.text}</p>
                          </div>
                        )}
                        {okImg(m.img) && (
                          <button type="button" onClick={() => setZoom(m.img as string)} className="mb-1 block">
                            <img src={m.img} alt="Foto enviada" loading="lazy" className="max-h-60 rounded-lg" />
                          </button>
                        )}
                        {okImg(m.aud) && (
                          <VoiceNote src={m.aud} />
                        )}
                        {m.text && <p className="cursor-pointer whitespace-pre-wrap break-words" onClick={() => setSheet(m)}>{m.text}</p>}
                        {m.react && Object.keys(m.react).length > 0 && (
                          <div className="mt-1 flex gap-1">{Object.entries(m.react).map(([u, e]) => <span key={u} className="rounded-full bg-black/30 px-1.5 text-sm">{e}</span>)}</div>
                        )}
                        <p className="mt-1 flex items-center justify-end gap-1.5 text-[11px] opacity-80">
                          {hhmm(m.at)}
                          {mine &&
                            (seenByOther >= tsMs(m.at) ? (
                              <CheckCheck className="h-3.5 w-3.5 text-neon" aria-label="Visto" />
                            ) : (
                              <Check className="h-3.5 w-3.5" aria-label="Enviado" />
                            ))}
                          <button type="button" onClick={() => setSheet(m)} className="opacity-70 hover:opacity-100" aria-label="Opciones del mensaje">
                            <MoreHorizontal className="h-4 w-4" />
                          </button>
                        </p>
                      </div>
                    </div>
                    </div>
                  );
                })}
                <div ref={endRef} />
              </div>

              {lists.blocked.includes(otherId) ? (
                <div className="flex items-center justify-between gap-3 border-t border-line p-3 text-sm text-mute">
                  <span>Bloqueaste a esta persona.</span>
                  <button type="button" className="btn-ghost !py-1.5" onClick={() => tg("blocked", ["Persona bloqueada.", "Persona desbloqueada."])}>Desbloquear</button>
                </div>
              ) : (
              <form onSubmit={onSubmit} className="relative flex items-end gap-2 border-t border-line p-3">
                {emojis && (
                  <div className="absolute bottom-full left-3 mb-2 flex gap-1 rounded-xl border border-line bg-raise p-2 animate-pop">
                    {["😀","😂","❤️","🔥","👍","🎮","😎","🙏"].map((e) => (
                      <button key={e} type="button" className="rounded-lg px-1.5 py-1 text-xl hover:bg-ink" onClick={() => setText((t) => t + e)}>{e}</button>
                    ))}
                  </div>
                )}
                {replyTo && (
                  <div className="absolute inset-x-0 bottom-full flex items-center gap-2 border-t border-line bg-surface px-3 py-2 text-sm animate-pop">
                    <CornerUpLeft className="h-4 w-4 text-neon" />
                    <p className="min-w-0 flex-1 truncate"><span className="text-neon">{replyTo.from === user.uid ? "Vos" : otherName}: </span>{replyTo.text ?? (replyTo.img ? "📷 Foto" : "🎤 Audio")}</p>
                    <button type="button" onClick={() => setReplyTo(null)} aria-label="Cancelar respuesta"><X className="h-4 w-4" /></button>
                  </div>
                )}
                <button type="button" className="btn-ghost !px-3" onClick={() => setEmojis((v) => !v)} aria-label="Emojis"><Smile className="h-5 w-5" /></button>
                <label htmlFor="chat-input" className="sr-only">Escribí un mensaje</label>
                <textarea
                  id="chat-input"
                  value={text}
                  rows={1}
                  maxLength={1000}
                  placeholder="Escribí un mensaje"
                  onChange={(e) => {
                    setText(e.target.value);
                    if (cid && conv && Date.now() - typingSent.current > 3000) {
                      typingSent.current = Date.now();
                      setTyping(cid, user.uid).catch(() => undefined);
                    }
                    e.target.style.height = "auto";
                    e.target.style.height = Math.min(e.target.scrollHeight, 128) + "px";
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      if (text.trim() && !sending) void submit({ text: text.trim() });
                    }
                  }}
                  className="input max-h-32 flex-1 resize-none"
                />
                {text.trim() ? (
                  <button type="submit" className="btn-primary !px-3" disabled={sending} aria-label="Enviar">
                    <Send className="h-5 w-5" />
                  </button>
                ) : rec ? (
                  <button type="button" className="btn-danger !px-3" onClick={() => rec.stop()} aria-label="Detener y enviar audio">
                    <Square className="h-4 w-4" /> {Math.floor(secs / 60)}:{String(secs % 60).padStart(2, "0")}
                  </button>
                ) : (
                  <button type="button" className="btn-primary !px-3" disabled={sending} onClick={() => void startRec()} aria-label="Grabar audio">
                    <Mic className="h-5 w-5" />
                  </button>
                )}
              </form>
              )}
            </>
          )}
        </section>
      </div>
      {confirm && (
        <Modal
          title={confirm.kind === "msg" ? "¿Eliminar este mensaje?" : "¿Eliminar este chat?"}
          onClose={() => setConfirm(null)}
          footer={
            <>
              <button type="button" className="btn-ghost" onClick={() => setConfirm(null)}>Cancelar</button>
              <button type="button" className="btn-danger" onClick={() => void doConfirm()}>Eliminar</button>
            </>
          }
        >
          {confirm.kind === "msg"
            ? "Se borra para las dos personas. No se puede deshacer."
            : "Se borra el historial solo para vos. La otra persona lo conserva, y el chat vuelve a aparecer si te escribe."}
        </Modal>
      )}
      {picker && (
        <Modal title="Nuevo chat" onClose={() => setPicker(false)} footer={<button type="button" className="btn-ghost" onClick={() => setPicker(false)}>Cerrar</button>}>
          <input value={people} onChange={(e) => setPeople(e.target.value)} placeholder="Buscar persona" className="input mb-2" autoFocus />
          <div className="max-h-72 overflow-y-auto">
            {suggest(profiles, verified, followers, new Set([uid ?? "", ...lists.blocked])).filter((p) => !p.hidden && p.name.toLowerCase().includes(people.trim().toLowerCase())).slice(0, 40).map((p) => (
              <button key={p.id} type="button" className="flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left hover:bg-raise" onClick={() => { setPicker(false); setPeople(""); navigate(`/mensajes/${p.id}`); }}>
                <Avatar profile={p} name={p.name} size={36} />
                <span className="truncate">{p.name}</span>
                {verified.has(p.id) && <VerifiedBadge />}
                <span className="ml-auto text-xs text-mute">{followers.get(p.id) ?? 0} seg.</span>
              </button>
            ))}
          </div>
        </Modal>
      )}
      {sheet && (
        <Modal title="Mensaje" onClose={() => setSheet(null)}>
          <div className="mb-3 flex justify-between text-2xl">
            {["👍", "❤️", "😂", "😮", "😢", "🔥"].map((e) => (
              <button key={e} type="button" className={cx("rounded-lg px-2 py-1 hover:bg-raise", sheet.react?.[user.uid] === e && "bg-raise")} onClick={() => void doReact(sheet, e)}>{e}</button>
            ))}
          </div>
          <div className="space-y-1">
            <button type="button" className="flex w-full items-center gap-3 rounded-lg px-2 py-2.5 text-left hover:bg-raise" onClick={() => { setReplyTo(sheet); setSheet(null); }}>
              <CornerUpLeft className="h-4 w-4" /> Responder
            </button>
            {sheet.text && (
              <button type="button" className="flex w-full items-center gap-3 rounded-lg px-2 py-2.5 text-left hover:bg-raise" onClick={() => { void navigator.clipboard?.writeText(sheet.text ?? ""); setSheet(null); push("Mensaje copiado.", { tone: "ok" }); }}>
                <Copy className="h-4 w-4" /> Copiar
              </button>
            )}
            {sheet.from === user.uid && (
              <button type="button" className="flex w-full items-center gap-3 rounded-lg px-2 py-2.5 text-left text-danger hover:bg-raise" onClick={() => { setConfirm({ kind: "msg", id: sheet.id }); setSheet(null); }}>
                <Trash2 className="h-4 w-4" /> Eliminar para todos
              </button>
            )}
          </div>
        </Modal>
      )}
      {zoom && <Lightbox url={zoom} onClose={() => setZoom(null)} />}
    </div>
  );
}
