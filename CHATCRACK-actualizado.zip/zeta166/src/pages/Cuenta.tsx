import { useState } from "react";
import { Link, Navigate, useParams } from "react-router-dom";
import { Archive, Ban, BellOff, ChevronLeft, ChevronRight, Heart, Lock, Star, X, type LucideIcon } from "lucide-react";
import { Avatar, VerifiedBadge } from "../components/Avatar";
import { EmptyState } from "../components/EmptyState";
import { useAuth } from "../hooks/useAuth";
import { useData } from "../hooks/useData";
import { useLists } from "../hooks/useLists";
import { useSignIn } from "../hooks/useSignIn";
import { useToast } from "../hooks/useToast";
import { cx } from "../lib/utils";
import { explain } from "../lib/errors";
import { saveProfile } from "../services/profiles";
import type { ListKey } from "../services/lists";

const SECTIONS: Record<string, { key: ListKey; title: string; icon: LucideIcon; help: string }> = {
  favoritos: { key: "fav", title: "Favoritos", icon: Star, help: "Personas que querés tener siempre a mano." },
  archivados: { key: "archived", title: "Archivados", icon: Archive, help: "Sus chats salen de la lista principal y los ves en la pestaña Archivados." },
  "mejores-amigos": { key: "close", title: "Mejores amigos", icon: Heart, help: "Tu lista cercana. Filtrá tus chats por ella." },
  silenciados: { key: "muted", title: "Silenciados", icon: BellOff, help: "No recibís avisos ni sonido de estos chats." },
  bloqueados: { key: "blocked", title: "Bloqueados", icon: Ban, help: "No aparecen en tus chats y no podés escribirles." },
};

export default function Cuenta() {
  const { section } = useParams();
  const { user, loading } = useAuth();
  const signIn = useSignIn();
  const { push } = useToast();
  const { profiles, verified, refresh } = useData();
  const { lists, toggle } = useLists();
  const [q, setQ] = useState("");

  if (loading) return null;
  if (!user) {
    return (
      <EmptyState title="Iniciá sesión para ver tu cuenta">
        <button type="button" className="btn-primary mt-3" onClick={() => void signIn()}>Iniciar sesión con Google</button>
      </EmptyState>
    );
  }

  const me = profiles.find((p) => p.id === user.uid);
  const nameOf = (id: string) => profiles.find((p) => p.id === id)?.name ?? "Usuario";
  const act = async (fn: () => Promise<unknown>) => {
    try {
      await fn();
    } catch (e) {
      push(explain(e), { tone: "error" });
    }
  };

  if (!section) {
    const rows: Array<[string, string, LucideIcon, string]> = [
      ...Object.entries(SECTIONS).map(([slug, s]): [string, string, LucideIcon, string] => [`/cuenta/${slug}`, s.title, s.icon, String(lists[s.key].length)]),
      ["/cuenta/privacidad", "Privacidad del perfil", Lock, me?.hidden ? "Oculto" : "Público"],
    ];
    return (
      <div className="mx-auto max-w-xl">
        <div className="mb-5 flex items-center gap-3">
          <Avatar profile={me} name={user.displayName ?? ""} size={56} />
          <div className="min-w-0">
            <p className="truncate font-display text-xl font-bold">{me?.name ?? user.displayName}</p>
            <Link to="/panel" className="text-sm text-neon hover:underline">Editar mi perfil</Link>
          </div>
        </div>
        <div className="overflow-hidden rounded-2xl border border-line bg-surface">
          {rows.map(([to, label, Icon, extra]) => (
            <Link key={to} to={to} className="flex items-center gap-3 border-b border-line px-4 py-3.5 last:border-0 hover:bg-raise">
              <Icon className="h-5 w-5 text-violet-soft" />
              <span className="flex-1">{label}</span>
              {extra && <span className="text-sm text-mute">{extra}</span>}
              <ChevronRight className="h-4 w-4 text-mute" />
            </Link>
          ))}
        </div>
      </div>
    );
  }

  const back = (
    <Link to="/cuenta" className="mb-4 inline-flex items-center gap-1 text-sm text-mute hover:text-white"><ChevronLeft className="h-4 w-4" /> Cuenta</Link>
  );

  if (section === "privacidad") {
    const hidden = !!me?.hidden;
    const setHidden = async (v: boolean) => {
      if (!me) return push("Primero creá tu perfil en Mi panel.", { tone: "error" });
      const { id: _id, createdAt, ...rest } = me;
      await act(async () => {
        await saveProfile(user.uid, { ...rest, hidden: v }, createdAt);
        await refresh();
        push(v ? "Tu perfil ya no aparece en el directorio." : "Tu perfil vuelve a aparecer.", { tone: "ok" });
      });
    };
    return (
      <div className="mx-auto max-w-xl">
        {back}
        <h1 className="font-display text-2xl font-bold">Privacidad del perfil</h1>
        <button type="button" role="switch" aria-checked={hidden} onClick={() => void setHidden(!hidden)} className="mt-4 flex w-full items-center justify-between rounded-2xl border border-line bg-surface p-4 text-left">
          <span>
            <span className="block font-medium">Ocultar mi perfil</span>
            <span className="text-sm text-mute">No salís en Explorar, Para ti ni en Nuevo chat. Quien ya tenga tu enlace puede abrirlo.</span>
          </span>
          <span className={cx("ml-3 h-6 w-11 shrink-0 rounded-full p-0.5 transition", hidden ? "bg-neon" : "bg-line")}>
            <span className={cx("block h-5 w-5 rounded-full bg-white transition", hidden && "translate-x-5")} />
          </span>
        </button>
        <Link to="/cuenta/bloqueados" className="mt-3 flex items-center justify-between rounded-2xl border border-line bg-surface p-4 hover:bg-raise">
          <span>Personas bloqueadas ({lists.blocked.length})</span><ChevronRight className="h-4 w-4 text-mute" />
        </Link>
      </div>
    );
  }

  const s = SECTIONS[section];
  if (!s) return <Navigate to="/cuenta" replace />;
  const ids = lists[s.key];
  const results = q.trim()
    ? profiles.filter((p) => p.id !== user.uid && !ids.includes(p.id) && p.name.toLowerCase().includes(q.trim().toLowerCase())).slice(0, 6)
    : [];

  return (
    <div className="mx-auto max-w-xl">
      {back}
      <h1 className="font-display text-2xl font-bold">{s.title}</h1>
      <p className="mt-1 text-sm text-mute">{s.help}</p>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar persona para agregar" className="input mt-4" />
      {results.map((p) => (
        <button key={p.id} type="button" className="mt-1 flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left hover:bg-raise" onClick={() => void act(async () => { await toggle(s.key, p.id, true); setQ(""); })}>
          <Avatar profile={p} name={p.name} size={36} />
          <span className="flex-1 truncate">{p.name}</span>
          <span className="text-sm text-neon">Agregar</span>
        </button>
      ))}
      <div className="mt-4 space-y-2">
        {ids.map((id) => (
          <div key={id} className="flex items-center gap-3 rounded-xl border border-line bg-surface p-3">
            <Avatar profile={profiles.find((p) => p.id === id)} name={nameOf(id)} size={40} />
            <Link to={`/mensajes/${id}`} className="flex min-w-0 flex-1 items-center gap-1 font-medium">
              <span className="truncate">{nameOf(id)}</span>
              {verified.has(id) && <VerifiedBadge />}
            </Link>
            <button type="button" className="btn-ghost !px-2.5 !py-1.5" aria-label="Quitar" onClick={() => void act(() => toggle(s.key, id, false))}><X className="h-4 w-4" /></button>
          </div>
        ))}
        {!ids.length && <EmptyState title="Todavía no hay nadie">Agregá personas con el buscador de arriba o desde un chat.</EmptyState>}
      </div>
    </div>
  );
}
