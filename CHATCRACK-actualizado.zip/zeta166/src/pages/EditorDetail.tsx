import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ExternalLink, Flag, MessageCircle, ShieldCheck, Star, UserCheck, UserPlus } from "lucide-react";
import { Avatar, Banner, VerifiedBadge } from "../components/Avatar";
import { EmptyState } from "../components/EmptyState";
import { Lightbox } from "../components/Lightbox";
import { Modal } from "../components/Modal";
import { Skeleton } from "../components/Skeleton";
import { useAuth } from "../hooks/useAuth";
import { useData, useProfile } from "../hooks/useData";
import { useSignIn } from "../hooks/useSignIn";
import { useToast } from "../hooks/useToast";
import { handle, okImg } from "../lib/utils";
import { follow, isFollowing, unfollow } from "../services/follows";
import { reportProfile, setFeatured, setVerified } from "../services/moderation";
import { countFollowers } from "../services/profiles";

export default function EditorDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();
  const { verified, featured, refresh } = useData();
  const { profile: p, loading } = useProfile(id);
  const signIn = useSignIn();
  const { push } = useToast();

  const [followers, setFollowers] = useState<number | null>(null);
  const [following, setFollowing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [zoom, setZoom] = useState<{ url: string; title: string } | null>(null);
  const [reporting, setReporting] = useState(false);
  const [reason, setReason] = useState("");

  const mine = !!user && user.uid === id;

  useEffect(() => {
    if (!id) return;
    let alive = true;
    setFollowers(null);
    countFollowers(id).then((n) => alive && setFollowers(n)).catch(() => alive && setFollowers(null));
    return () => {
      alive = false;
    };
  }, [id]);

  useEffect(() => {
    setFollowing(false);
    if (!user || !id || user.uid === id) return;
    let alive = true;
    isFollowing(user.uid, id).then((v) => alive && setFollowing(v)).catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [user, id]);

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-40" />
        <Skeleton className="h-8 w-1/3" />
        <Skeleton className="h-24" />
      </div>
    );
  }
  if (!p || !id) {
    return (
      <EmptyState title="Este perfil ya no existe">
        <Link to="/editores" className="text-neon hover:underline">Volver a los editores</Link>
      </EmptyState>
    );
  }

  const isVerified = verified.has(p.id);
  const isFeatured = featured.has(p.id);
  const works = (p.works ?? []).filter((w) => okImg(w.url));
  const links = [p.p1, p.p2, p.p3].filter((u): u is string => /^https:\/\//.test(u ?? ""));
  const socials: Array<[string, string]> = [];
  if (handle(p.yt)) socials.push(["YouTube", `https://youtube.com/@${handle(p.yt)}`]);
  if (handle(p.tt)) socials.push(["TikTok", `https://tiktok.com/@${handle(p.tt)}`]);
  if (handle(p.ig)) socials.push(["Instagram", `https://instagram.com/${handle(p.ig)}`]);

  const onMessage = async () => {
    if (!(await signIn())) return;
    navigate(`/mensajes/${p.id}`);
  };

  const onFollow = async () => {
    if (!(await signIn())) return;
    const uid = user?.uid;
    if (!uid) return;
    setBusy(true);
    try {
      if (following) {
        await unfollow(uid, p.id);
        setFollowing(false);
        setFollowers((n) => (n === null ? n : Math.max(0, n - 1)));
      } else {
        await follow(uid, p.id);
        setFollowing(true);
        setFollowers((n) => (n === null ? n : n + 1));
      }
    } catch {
      push("No se pudo actualizar el seguimiento. Probá de nuevo.", { tone: "error" });
    } finally {
      setBusy(false);
    }
  };

  const onReport = async () => {
    if (!user || !reason.trim()) return;
    try {
      await reportProfile(user.uid, p.id, reason.trim());
      push("Reporte enviado. Lo revisamos pronto.", { tone: "ok" });
    } catch {
      push("No se pudo enviar el reporte. Si ya reportaste este perfil, no hace falta repetirlo.", { tone: "error" });
    }
    setReporting(false);
    setReason("");
  };

  const adminToggle = async (kind: "verify" | "feature") => {
    try {
      if (kind === "verify") await setVerified(p.id, !isVerified);
      else await setFeatured(p.id, !isFeatured);
      await refresh();
      push("Listo.", { tone: "ok" });
    } catch {
      push("No se pudo aplicar el cambio.", { tone: "error" });
    }
  };

  return (
    <div>
      <Link to="/editores" className="text-sm text-mute hover:text-white">‹ Volver a los editores</Link>

      <div className="mt-4 overflow-hidden rounded-3xl border border-line bg-surface">
        <Banner profile={p} className="h-36 sm:h-52" />
        <div className="px-5 pb-6 sm:px-8">
          <Avatar profile={p} size={92} className="-mt-12 border-4 border-surface" />
          <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1">
            <h1 className="flex items-center gap-2 font-display text-3xl font-bold">
              {p.name}
              {isVerified && <VerifiedBadge />}
            </h1>
            <span className="rounded-full border border-violet/50 px-3 py-0.5 text-sm text-violet-soft">{p.cat}</span>
          </div>
          <p className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-mute">
            <span>{followers === null ? "Seguidores: –" : `${followers} ${followers === 1 ? "seguidor" : "seguidores"}`}</span>
            <span className="flex items-center gap-1.5">
              <span className={"h-2 w-2 rounded-full " + (p.av ? "bg-neon shadow-[0_0_8px_#B6FF2E]" : "bg-mute/50")} />
              {p.av ? "Disponible para trabajos" : "Sin cupo por ahora"}
            </span>
          </p>
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_320px]">
        <div className="space-y-8">
          {(p.bio || p.soft || p.price) && (
            <section className="space-y-3">
              {p.bio && <p className="max-w-prose whitespace-pre-line text-base leading-relaxed">{p.bio}</p>}
              {p.soft && <p className="text-sm text-mute"><span className="font-medium text-white">Programas:</span> {p.soft}</p>}
              {p.price && <p className="text-sm text-mute"><span className="font-medium text-white">Desde:</span> {p.price}</p>}
            </section>
          )}

          {links.length > 0 && (
            <section>
              <h2 className="mb-3 font-display text-xl font-semibold">Portafolio</h2>
              <div className="flex flex-wrap gap-2">
                {links.map((u, i) => (
                  <a key={u} href={u} target="_blank" rel="noopener noreferrer" className="btn-ghost">
                    Trabajo {i + 1} <ExternalLink className="h-4 w-4" />
                  </a>
                ))}
              </div>
            </section>
          )}

          <section>
            <h2 className="mb-3 font-display text-xl font-semibold">Trabajos</h2>
            {works.length ? (
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {works.map((w) => (
                  <button
                    key={w.url}
                    type="button"
                    onClick={() => setZoom(w)}
                    className="group relative aspect-video overflow-hidden rounded-xl border border-line focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neon"
                  >
                    <img src={w.url} alt={w.title || "Trabajo"} loading="lazy" className="h-full w-full object-cover transition group-hover:scale-105" />
                    {w.title && <span className="absolute inset-x-0 bottom-0 truncate bg-gradient-to-t from-black/85 to-transparent p-2 text-left text-xs">{w.title}</span>}
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-sm text-mute">{mine ? "Todavía no subiste trabajos. Podés hacerlo desde Mi panel." : "Este editor todavía no subió trabajos."}</p>
            )}
          </section>
        </div>

        <aside className="space-y-4">
          <div className="rounded-2xl border border-line bg-surface p-4">
            <h2 className="mb-3 font-display text-lg font-semibold">Contactar</h2>
            {mine ? (
              <div className="space-y-2">
                <p className="text-sm text-mute">Este es tu perfil público.</p>
                <Link to="/panel" className="btn-ghost w-full">Editar mi perfil</Link>
              </div>
            ) : (
              <div className="space-y-2">
                <button type="button" onClick={() => void onMessage()} className="btn-primary w-full">
                  <MessageCircle className="h-4 w-4" /> Enviar mensaje
                </button>
                {p.wa && (
                  <a href={`https://wa.me/${p.wa.replace(/\D/g, "")}`} target="_blank" rel="noopener noreferrer" className="btn-ghost w-full">
                    Escribir por WhatsApp
                  </a>
                )}
                <button type="button" disabled={busy} onClick={() => void onFollow()} className="btn-ghost w-full">
                  {following ? <UserCheck className="h-4 w-4 text-neon" /> : <UserPlus className="h-4 w-4" />}
                  {following ? "Siguiendo" : "Seguir"}
                </button>
              </div>
            )}
          </div>

          <div className="rounded-2xl border border-line bg-surface p-4">
            <h2 className="mb-3 font-display text-lg font-semibold">Seguir en redes</h2>
            <div className="flex flex-col gap-2">
              {socials.map(([n, u]) => (
                <a key={n} href={u} target="_blank" rel="noopener noreferrer" className="btn-ghost">
                  Seguir en {n} <ExternalLink className="h-4 w-4" />
                </a>
              ))}
              {p.dc && (
                <button
                  type="button"
                  className="btn-ghost"
                  onClick={() =>
                    navigator.clipboard
                      ?.writeText(p.dc as string)
                      .then(() => push("Usuario de Discord copiado.", { tone: "ok" }))
                      .catch(() => push("No se pudo copiar.", { tone: "error" }))
                  }
                >
                  Discord: {p.dc}
                </button>
              )}
              {!socials.length && !p.dc && <p className="text-sm text-mute">Todavía no cargó sus redes.</p>}
            </div>
          </div>

          {isAdmin && !mine && (
            <div className="rounded-2xl border border-violet/50 bg-surface p-4">
              <h2 className="mb-3 flex items-center gap-2 font-display text-lg font-semibold">
                <ShieldCheck className="h-5 w-5 text-violet-soft" /> Administración
              </h2>
              <div className="flex flex-col gap-2">
                <button type="button" className="btn-ghost" onClick={() => void adminToggle("verify")}>
                  {isVerified ? "Quitar verificación" : "Verificar"}
                </button>
                <button type="button" className="btn-ghost" onClick={() => void adminToggle("feature")}>
                  <Star className="h-4 w-4" /> {isFeatured ? "Quitar de destacados" : "Destacar en el inicio"}
                </button>
              </div>
            </div>
          )}

          {!mine && (
            <button
              type="button"
              className="flex items-center gap-2 text-sm text-mute hover:text-white"
              onClick={async () => {
                if (await signIn()) setReporting(true);
              }}
            >
              <Flag className="h-4 w-4" /> Reportar perfil
            </button>
          )}
        </aside>
      </div>

      {zoom && <Lightbox url={zoom.url} title={zoom.title} onClose={() => setZoom(null)} />}
      {reporting && (
        <Modal
          title="Reportar perfil"
          onClose={() => setReporting(false)}
          footer={
            <>
              <button type="button" className="btn-ghost" onClick={() => setReporting(false)}>Cancelar</button>
              <button type="button" className="btn-primary" disabled={!reason.trim()} onClick={() => void onReport()}>Enviar reporte</button>
            </>
          }
        >
          <label htmlFor="report-reason" className="mb-2 block text-white">¿Por qué querés reportar este perfil?</label>
          <textarea id="report-reason" value={reason} maxLength={300} rows={4} onChange={(e) => setReason(e.target.value)} className="input" />
          <p className="mt-1 text-xs">{reason.length} de 300 caracteres</p>
        </Modal>
      )}
    </div>
  );
}
