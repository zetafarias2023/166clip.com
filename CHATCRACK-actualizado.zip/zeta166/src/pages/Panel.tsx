import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { ImagePlus, Lock, Trash2 } from "lucide-react";
import { Avatar, Banner } from "../components/Avatar";
import { EmptyState } from "../components/EmptyState";
import { Field } from "../components/Field";
import { Modal } from "../components/Modal";
import { Skeleton } from "../components/Skeleton";
import { CATS, COLS, MAX_WORKS, PRO_PRICE_USD } from "../config";
import { useAuth } from "../hooks/useAuth";
import { useData } from "../hooks/useData";
import { useSignIn } from "../hooks/useSignIn";
import { useToast } from "../hooks/useToast";
import { AVATARS, AvatarArt, TIER_LABEL, TIER_MIN, tierUnlocked, type Tier } from "../lib/avatars";
import { cx, okImg } from "../lib/utils";
import { requestVerification } from "../services/moderation";
import { fetchProStatus, paypalUrl, requestPro } from "../services/pro";
import { countFollowers, deleteProfileCascade, fetchProfile, saveProfile } from "../services/profiles";
import { checkImage, deleteByUrl, uploadImage } from "../services/storage";
import type { Profile, ProfileInput, Work } from "../types";

const emptyForm = (name: string): ProfileInput => ({
  name, cat: CATS[0], soft: "", price: "", bio: "", yt: "", tt: "", ig: "", wa: "", dc: "",
  p1: "", p2: "", p3: "", col: 0, av: true, works: [], avatarUrl: "", avatarId: "zorro", bannerUrl: "",
});

export default function Panel() {
  const { user, loading: authLoading, isAdmin } = useAuth();
  const [followers, setFollowers] = useState(0);
  const [isPro, setIsPro] = useState(false);
  const [proPending, setProPending] = useState(false);
  const [txn, setTxn] = useState("");
  const { verified, refresh } = useData();
  const signIn = useSignIn();
  const { push } = useToast();

  const [existing, setExisting] = useState<Profile | null>(null);
  const [form, setForm] = useState<ProfileInput>(emptyForm(""));
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [requested, setRequested] = useState(false);
  const removed = useRef<string[]>([]);

  const uid = user?.uid;

  useEffect(() => {
    if (!uid) {
      setLoading(false);
      return;
    }
    let alive = true;
    setLoading(true);
    fetchProfile(uid)
      .then((p) => {
        if (!alive) return;
        setExisting(p);
        if (p) {
          const { id: _id, createdAt: _c, ...rest } = p;
          setForm({ ...emptyForm(""), ...rest, works: (rest.works ?? []).filter((w) => okImg(w.url)) });
        } else {
          setForm(emptyForm(user?.displayName?.slice(0, 40) ?? ""));
        }
      })
      .catch(() => push("No se pudo cargar tu perfil.", { tone: "error" }))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [uid]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (uid) countFollowers(uid).then(setFollowers).catch(() => undefined);
  }, [uid]);

  useEffect(() => {
    if (uid) fetchProStatus(uid).then((s) => { setIsPro(s.pro); setProPending(s.pending); }).catch(() => undefined);
  }, [uid]);

  if (authLoading) return null;
  if (!user) {
    return (
      <EmptyState title="Iniciá sesión para crear tu perfil">
        <button type="button" className="btn-primary mt-3" onClick={() => void signIn()}>Iniciar sesión con Google</button>
      </EmptyState>
    );
  }
  if (loading) return <div className="space-y-4"><Skeleton className="h-10 w-1/3" /><Skeleton className="h-64" /></div>;

  const set = <K extends keyof ProfileInput>(k: K, v: ProfileInput[K]) => setForm((f) => ({ ...f, [k]: v }));
  const text = (k: keyof ProfileInput, id: string, max: number, extra?: { placeholder?: string; inputMode?: "tel" }) => (
    <input
      id={id}
      className="input"
      maxLength={max}
      placeholder={extra?.placeholder}
      inputMode={extra?.inputMode}
      value={(form[k] as string) ?? ""}
      onChange={(e) => set(k, e.target.value as never)}
    />
  );

  const addWorks = async (files: File[]) => {
    for (const f of files) {
      if ((form.works?.length ?? 0) >= MAX_WORKS) {
        push(`Máximo ${MAX_WORKS} trabajos.`, { tone: "error" });
        break;
      }
      const err = checkImage(f, "portfolio");
      if (err) {
        push(`${f.name}: ${err}`, { tone: "error" });
        continue;
      }
      setUploading("works");
      try {
        const url = await uploadImage("portfolio", user.uid, f);
        setForm((cur) => ({ ...cur, works: [...(cur.works ?? []), { url, title: "" }] }));
      } catch {
        push(`No se pudo subir ${f.name}.`, { tone: "error" });
      }
    }
    setUploading(null);
    push("Tocá Guardar perfil para publicar tus trabajos.", { tone: "info" });
  };

  const removeWork = (i: number) => {
    const w = form.works?.[i];
    if (w) removed.current.push(w.url);
    set("works", (form.works ?? []).filter((_, j) => j !== i));
  };
  const setTitle = (i: number, title: string) =>
    set("works", (form.works ?? []).map((w: Work, j) => (j === i ? { ...w, title } : w)));

  const onSave = async () => {
    if (!form.name.trim()) return push("Poné tu nombre o alias.", { tone: "error" });
    for (const k of ["p1", "p2", "p3"] as const) {
      const v = (form[k] ?? "").trim();
      if (v && !/^https:\/\//.test(v)) return push("Los enlaces del portafolio tienen que empezar con https://", { tone: "error" });
    }
    setSaving(true);
    try {
      const chosen = AVATARS.find((a) => a.id === form.avatarId);
      if (!chosen) return push("Elegí un avatar.", { tone: "error" });
      if (!tierUnlocked(chosen.tier, followers, isAdmin || isPro)) return push("Ese avatar todavía está bloqueado.", { tone: "error" });
      if (existing?.bannerUrl) removed.current.push(existing.bannerUrl);
      if (existing?.avatarUrl) removed.current.push(existing.avatarUrl);
      const clean: ProfileInput = {
        ...form,
        bannerUrl: "",
        avatarUrl: "",
        name: form.name.trim(),
        wa: (form.wa ?? "").replace(/\D/g, ""),
        works: (form.works ?? []).filter((w) => okImg(w.url)).map((w) => ({ url: w.url, title: (w.title || "").slice(0, 60) })),
      };
      await saveProfile(user.uid, clean, existing?.createdAt);
      await Promise.allSettled(removed.current.map(deleteByUrl));
      removed.current = [];
      setExisting(await fetchProfile(user.uid));
      await refresh();
      push("Perfil guardado.", { tone: "ok" });
    } catch (e) {
      const code = (e as { code?: string }).code ?? "desconocido";
      push(`No se pudo guardar el perfil (${code}). ${code === "permission-denied" ? "Publicá las reglas: firebase deploy --only firestore:rules,storage" : "Probá de nuevo."}`, { tone: "error" });
    } finally {
      setSaving(false);
    }
  };

  const onDelete = async () => {
    setConfirmDelete(false);
    try {
      await deleteProfileCascade(user.uid, existing);
      setExisting(null);
      setForm(emptyForm(user.displayName?.slice(0, 40) ?? ""));
      await refresh();
      push("Perfil eliminado.", { tone: "ok" });
    } catch {
      push("No se pudo eliminar el perfil.", { tone: "error" });
    }
  };

  const onPaid = async () => {
    try {
      await requestPro(user.uid, form.name.trim() || user.displayName || "", txn);
      setProPending(true);
      setTxn("");
      push("¡Gracias! Revisamos tu pago y desbloqueamos tus avatares.", { tone: "ok" });
    } catch {
      push("No se pudo enviar el aviso. Probá de nuevo.", { tone: "error" });
    }
  };

  const onVerify = async () => {
    try {
      await requestVerification(user.uid, form.name.trim() || user.displayName || "");
      setRequested(true);
      push("Solicitud enviada. La revisamos pronto.", { tone: "ok" });
    } catch {
      push("No se pudo enviar la solicitud.", { tone: "error" });
    }
  };

  const preview: Profile = { id: user.uid, ...form };
  const isVerified = verified.has(user.uid);

  return (
    <div className="max-w-3xl">
      <h1 className="font-display text-3xl font-bold">Mi panel</h1>
      <p className="mt-1 text-mute">
        {existing ? "Editá tu perfil público. Los cambios se ven cuando tocás Guardar perfil." : "Todavía no tenés perfil. Completalo y guardalo para aparecer en el directorio."}
      </p>

      <div className="mt-6 overflow-hidden rounded-2xl border border-line bg-surface">
        <Banner profile={preview} className="h-32 sm:h-40" />
        <div className="flex items-end gap-4 px-5 pb-5">
          <Avatar profile={preview} size={84} className="-mt-10 border-4 border-surface" />
          <p className="pb-1 text-sm text-mute">Elegí tu avatar abajo. Tenés {followers} {followers === 1 ? "seguidor" : "seguidores"}.</p>
        </div>
      </div>

      <div className="mt-6 rounded-2xl border border-line bg-surface p-5">
        <h2 className="font-display text-xl font-semibold">Tu avatar</h2>
        <p className="mb-4 text-sm text-mute">Los avatares Pro se desbloquean con {TIER_MIN.pro} seguidores y los de Élite con {TIER_MIN.elite}. O comprando Chatcrack Pro.</p>
        {isPro && <p className="mb-4 rounded-xl border border-neon/40 bg-neon/10 p-3 text-sm text-neon">Chatcrack Pro activo: tenés todos los avatares desbloqueados.</p>}
        {!isPro && !isAdmin && (
          <div className="mb-5 rounded-xl border border-violet/50 bg-violet/10 p-4">
            <p className="font-display text-lg font-semibold">Desbloqueá todos los avatares por USD {PRO_PRICE_USD}</p>
            <p className="mt-1 text-sm text-mute">Pago único con PayPal. Después de pagar, pegá acá el ID de transacción (está en el mail o recibo de PayPal) y lo revisamos.</p>
            <a href={paypalUrl(user.uid)} target="_blank" rel="noopener noreferrer" className="btn-primary mt-3 inline-flex">Pagar USD {PRO_PRICE_USD} con PayPal</a>
            {proPending ? (
              <p className="mt-3 text-sm">Tu pago está en revisión. Cuando lo confirmemos se desbloquean todos los avatares.</p>
            ) : (
              <div className="mt-3 flex flex-wrap gap-2">
                <input className="input !w-auto min-w-0 flex-1" maxLength={40} placeholder="ID de transacción de PayPal" aria-label="ID de transacción de PayPal" value={txn} onChange={(e) => setTxn(e.target.value)} />
                <button type="button" className="btn-ghost" disabled={txn.trim().length < 8} onClick={() => void onPaid()}>Ya pagué</button>
              </div>
            )}
          </div>
        )}
        {(["base", "pro", "elite"] as Tier[]).map((tier) => {
          const open = tierUnlocked(tier, followers, isAdmin || isPro);
          return (
            <div key={tier} className="mb-5 last:mb-0">
              <p className="mb-2 flex items-center gap-2 text-sm font-medium">
                {TIER_LABEL[tier]}
                {!open && <span className="flex items-center gap-1 text-xs font-normal text-mute"><Lock className="h-3.5 w-3.5" /> Te faltan {TIER_MIN[tier] - followers} seguidores</span>}
              </p>
              <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
                {AVATARS.filter((a) => a.tier === tier).map((a) => {
                  const picked = form.avatarId === a.id;
                  return (
                    <button
                      key={a.id}
                      type="button"
                      disabled={!open}
                      onClick={() => set("avatarId", a.id)}
                      aria-pressed={picked}
                      aria-label={a.name}
                      title={open ? a.name : `${a.name} (bloqueado)`}
                      className={cx("relative aspect-square overflow-hidden rounded-full border-2 transition", picked ? "border-neon" : "border-transparent", !open && "cursor-not-allowed")}
                    >
                      <span className={cx("block h-full w-full", !open && "opacity-35 grayscale")}><AvatarArt id={a.id} size={96} /></span>
                      {!open && <Lock className="absolute left-1/2 top-1/2 h-5 w-5 -translate-x-1/2 -translate-y-1/2 text-white drop-shadow" />}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 space-y-5 rounded-2xl border border-line bg-surface p-5">
        <Field label="Nombre o alias" htmlFor="f-name">{text("name", "f-name", 40)}</Field>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Categoría" htmlFor="f-cat">
            <select id="f-cat" className="input" value={form.cat} onChange={(e) => set("cat", e.target.value)}>
              {CATS.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Precio desde" htmlFor="f-price">{text("price", "f-price", 30, { placeholder: "USD 10 por video" })}</Field>
        </div>
        <Field label="Programas que usás" htmlFor="f-soft">{text("soft", "f-soft", 60, { placeholder: "Premiere, After Effects, CapCut" })}</Field>
        <Field label="Sobre vos" htmlFor="f-bio" hint={`${(form.bio ?? "").length} de 400 caracteres`}>
          <textarea id="f-bio" rows={4} maxLength={400} className="input" placeholder="Contá qué editás, tu estilo y tus tiempos de entrega" value={form.bio ?? ""} onChange={(e) => set("bio", e.target.value)} />
        </Field>

        <div>
          <p className="mb-1.5 text-sm font-medium">Color de tu perfil</p>
          <p className="mb-2 text-xs text-mute">Es el fondo de tu tarjeta y de tu foto si no subiste una.</p>
          <div className="flex flex-wrap gap-2">
            {COLS.map((g, i) => (
              <button key={g} type="button" onClick={() => set("col", i)} aria-label={`Color ${i + 1}`} aria-pressed={form.col === i}
                style={{ background: g }} className={cx("h-9 w-9 rounded-full border-2", form.col === i ? "border-white" : "border-transparent")} />
            ))}
          </div>
        </div>

        <label className="flex cursor-pointer items-center gap-2 text-sm">
          <input type="checkbox" className="h-4 w-4 accent-[#B6FF2E]" checked={!!form.av} onChange={(e) => set("av", e.target.checked)} />
          Estoy disponible para nuevos trabajos
        </label>
      </div>

      <div className="mt-6 rounded-2xl border border-line bg-surface p-5">
        <h2 className="font-display text-xl font-semibold">Redes y contacto</h2>
        <p className="mb-4 text-sm text-mute">Todo es opcional. Lo que cargues acá es público.</p>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="YouTube (usuario del canal)" htmlFor="f-yt">{text("yt", "f-yt", 60, { placeholder: "@tucanal" })}</Field>
          <Field label="TikTok" htmlFor="f-tt">{text("tt", "f-tt", 60, { placeholder: "@usuario" })}</Field>
          <Field label="Instagram" htmlFor="f-ig">{text("ig", "f-ig", 60, { placeholder: "@usuario" })}</Field>
          <Field label="WhatsApp (con código de país)" htmlFor="f-wa" hint="Se muestra a todo el mundo. Si sos menor de 18, no lo cargues.">{text("wa", "f-wa", 20, { placeholder: "5491122334455", inputMode: "tel" })}</Field>
          <Field label="Discord (usuario)" htmlFor="f-dc">{text("dc", "f-dc", 40)}</Field>
          <Field label="Portafolio 1 (enlace https)" htmlFor="f-p1">{text("p1", "f-p1", 200, { placeholder: "https://" })}</Field>
          <Field label="Portafolio 2" htmlFor="f-p2">{text("p2", "f-p2", 200, { placeholder: "https://" })}</Field>
          <Field label="Portafolio 3" htmlFor="f-p3">{text("p3", "f-p3", 200, { placeholder: "https://" })}</Field>
        </div>
      </div>

      <div className="mt-6 rounded-2xl border border-line bg-surface p-5">
        <h2 className="font-display text-xl font-semibold">Mis trabajos</h2>
        <p className="mb-4 text-sm text-mute">Subí miniaturas, ediciones y diseños (JPG, PNG, WEBP o GIF de hasta 25 MB, máximo {MAX_WORKS}). Los compradores los ven en tu perfil.</p>
        <label className={cx("btn-ghost cursor-pointer", uploading === "works" && "opacity-60")}>
          <ImagePlus className="h-4 w-4" /> {uploading === "works" ? "Subiendo…" : "Subir imágenes"}
          <input type="file" hidden multiple accept="image/jpeg,image/png,image/webp,image/gif" onChange={(e) => { const fs = [...(e.target.files ?? [])]; e.target.value = ""; if (fs.length) void addWorks(fs); }} />
        </label>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          {(form.works ?? []).map((w, i) => (
            <div key={w.url} className="space-y-2 rounded-xl border border-line p-2">
              <img src={w.url} alt={w.title || "Trabajo"} className="aspect-video w-full rounded-lg object-cover" />
              <input className="input !py-2" maxLength={60} placeholder="Título" aria-label="Título del trabajo" value={w.title} onChange={(e) => setTitle(i, e.target.value)} />
              <button type="button" className="btn-ghost w-full !py-1.5" onClick={() => removeWork(i)}>
                <Trash2 className="h-4 w-4" /> Quitar
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-6 rounded-2xl border border-line bg-surface p-5">
        <h2 className="font-display text-xl font-semibold">Verificación</h2>
        <p className="mb-3 text-sm text-mute">La insignia la otorga la academia después de revisar tu cuenta. Primero guardá tu perfil.</p>
        {isVerified ? (
          <p className="text-neon">Tu perfil está verificado.</p>
        ) : (
          <button type="button" className="btn-ghost" disabled={!existing || requested} onClick={() => void onVerify()}>
            {requested ? "Solicitud enviada" : "Pedir verificación"}
          </button>
        )}
      </div>

      <div className="sticky bottom-0 mt-6 flex flex-wrap gap-2 border-t border-line bg-ink/90 py-4 backdrop-blur">
        <button type="button" className="btn-primary" disabled={saving || uploading !== null} onClick={() => void onSave()}>
          {saving ? "Guardando…" : "Guardar perfil"}
        </button>
        {existing && <Link to={`/editor/${user.uid}`} className="btn-ghost">Ver mi perfil público</Link>}
        {existing && <button type="button" className="btn-danger" onClick={() => setConfirmDelete(true)}>Eliminar mi perfil</button>}
      </div>

      {confirmDelete && (
        <Modal
          title="¿Eliminar tu perfil?"
          onClose={() => setConfirmDelete(false)}
          footer={
            <>
              <button type="button" className="btn-ghost" onClick={() => setConfirmDelete(false)}>Cancelar</button>
              <button type="button" className="btn-danger" onClick={() => void onDelete()}>Eliminar perfil</button>
            </>
          }
        >
          Se borran tu perfil, tus imágenes y tus seguidores. Tus chats quedan para la otra persona. Esta acción no se puede deshacer.
        </Modal>
      )}
    </div>
  );
}
