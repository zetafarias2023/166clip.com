import { useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { Search } from "lucide-react";
import { EmptyState } from "../components/EmptyState";
import { ProfileCard } from "../components/ProfileCard";
import { ProfileCardSkeleton } from "../components/Skeleton";
import { CATS } from "../config";
import { useAuth } from "../hooks/useAuth";
import { useData } from "../hooks/useData";
import { cx, tsMs } from "../lib/utils";

export default function Editors() {
  const { profiles, verified, loading } = useData();
  const { user } = useAuth();
  const [sp, setSp] = useSearchParams();
  const q = sp.get("q") ?? "";
  const cat = sp.get("cat") ?? "Todos";
  const onlyAv = sp.get("av") === "1";
  const onlyVf = sp.get("vf") === "1";
  const sort = sp.get("sort") ?? "recientes";

  const set = (k: string, v: string) => {
    const n = new URLSearchParams(sp);
    if (v) n.set(k, v);
    else n.delete(k);
    setSp(n, { replace: true });
  };

  const list = useMemo(() => {
    const t = q.trim().toLowerCase();
    const r = profiles.filter(
      (p) =>
        (cat === "Todos" || p.cat === cat) &&
        (!onlyAv || p.av) &&
        (!onlyVf || verified.has(p.id)) &&
        (!t || [p.name, p.soft, p.bio, p.cat].join(" ").toLowerCase().includes(t)),
    );
    const recent = (a: typeof r[number], b: typeof r[number]) => tsMs(b.createdAt) - tsMs(a.createdAt);
    if (sort === "nombre") r.sort((a, b) => a.name.localeCompare(b.name, "es"));
    else if (sort === "verificados") r.sort((a, b) => Number(verified.has(b.id)) - Number(verified.has(a.id)) || recent(a, b));
    else r.sort(recent);
    return r;
  }, [profiles, verified, q, cat, onlyAv, onlyVf, sort]);

  return (
    <div>
      <h1 className="font-display text-3xl font-bold">Editores</h1>
      <p className="mt-1 text-mute">Filtrá por categoría, disponibilidad o programa y mirá sus perfiles.</p>

      <div className="mt-6 space-y-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-mute" />
          <label htmlFor="ed-q" className="sr-only">Buscar editores</label>
          <input id="ed-q" value={q} onChange={(e) => set("q", e.target.value)} placeholder="Buscar por nombre, programa o descripción" className="input !pl-11" />
        </div>

        <div className="flex flex-wrap gap-2" role="group" aria-label="Categorías">
          {["Todos", ...CATS].map((c) => (
            <button key={c} type="button" aria-pressed={cat === c} onClick={() => set("cat", c === "Todos" ? "" : c)} className={cx("chip", cat === c && "chip-on")}>
              {c}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-3 text-sm">
          <label className="flex cursor-pointer items-center gap-2">
            <input type="checkbox" checked={onlyAv} onChange={(e) => set("av", e.target.checked ? "1" : "")} className="h-4 w-4 accent-[#B6FF2E]" />
            Solo disponibles
          </label>
          <label className="flex cursor-pointer items-center gap-2">
            <input type="checkbox" checked={onlyVf} onChange={(e) => set("vf", e.target.checked ? "1" : "")} className="h-4 w-4 accent-[#B6FF2E]" />
            Solo verificados
          </label>
          <div className="ml-auto flex items-center gap-2">
            <label htmlFor="ed-sort" className="text-mute">Ordenar</label>
            <select id="ed-sort" value={sort} onChange={(e) => set("sort", e.target.value === "recientes" ? "" : e.target.value)} className="input !w-auto !py-2">
              <option value="recientes">Más recientes</option>
              <option value="verificados">Verificados primero</option>
              <option value="nombre">Nombre (A a Z)</option>
            </select>
          </div>
        </div>
      </div>

      <p className="mt-6 text-sm text-mute" aria-live="polite">
        {loading ? "Cargando editores…" : `${list.length} ${list.length === 1 ? "editor" : "editores"}`}
      </p>

      <div className="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {loading
          ? Array.from({ length: 6 }, (_, i) => <ProfileCardSkeleton key={i} />)
          : list.map((p) => <ProfileCard key={p.id} p={p} mine={p.id === user?.uid} />)}
      </div>

      {!loading && !list.length && (
        <div className="mt-4">
          <EmptyState title={profiles.length ? "No encontré editores con ese filtro" : "Todavía no hay editores"}>
            {profiles.length ? "Probá con otra categoría o quitá algún filtro." : "Iniciá sesión y creá el primer perfil desde Mi panel."}
          </EmptyState>
        </div>
      )}
    </div>
  );
}
