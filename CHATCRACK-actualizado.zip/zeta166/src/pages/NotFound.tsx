import { Link } from "react-router-dom";
import { EmptyState } from "../components/EmptyState";

export default function NotFound() {
  return (
    <EmptyState title="No encontramos esta página">
      <Link to="/" className="text-neon hover:underline">Volver al inicio</Link>
    </EmptyState>
  );
}
