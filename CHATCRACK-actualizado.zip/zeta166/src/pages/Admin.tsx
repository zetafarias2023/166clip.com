import { useEffect, useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { EmptyState } from "../components/EmptyState";
import { useAuth } from "../hooks/useAuth";
import { useData } from "../hooks/useData";
import { useToast } from "../hooks/useToast";
import { cx, tsMs } from "../lib/utils";
import { explain } from "../lib/errors";
import {
  approveVerification, dismissReport, rejectVerification, setFeatured, setVerified, subscribeReports, subscribeVerifyRequests,
} from "../services/moderation";
import { approvePro, rejectPro, subscribeProRequests } from "../services/pro";
import type { ProRequest, Report, VerifyRequest } from "../types";

type Tab = "usuarios" | "verificaciones" | "reportes" | "destacados" | "pagos";

export default function Admin() {
  const { isAdmin, loading } = useAuth();
  const { profiles, verified, featured, followers, refresh } = useData();
  const { push } = useToast();
  const [tab, setTab] = useState<Tab>("verificaciones");
  const [requests, setRequests] = useState<VerifyRequest[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [payments, setPayments] = useState<ProRequest[]>([]);
  const [find, setFind] = useState("");

  useEffect(() => {
    if (!isAdmin) return;
    const a = subscribeVerifyRequests(setRequests);
    const b = subscribeReports(setReports);
    const c = subscribeProRequests(setPayments);
    return () => {
      a();
      b();
      c();
    };
  }, [isAdmin]);

  if (loading) return null;
  if (!isAdmin) return <Navigate to="/" replace />;

  const run = async (fn: () => Promise<unknown>, ok = "Listo.") => {
    try {
      await fn();
      push(ok, { tone: "ok" });
    } catch (e) {
      push(explain(e, "No se pudo completar la acción."), { tone: "error" });
    }
  };
  const nameOf = (id: string) => profiles.find((p) => p.id === id)?.name ?? id;
  const tabs: Array<[Tab, string, number]> = [
    ["usuarios", "Usuarios", profiles.length],
    ["verificaciones", "Verificaciones", requests.length],
    ["reportes", "Reportes", reports.length],
    ["destacados", "Destacados", featured.size],
    ["pagos", "Pagos Pro", payments.length],
  ];

  return (
    <div className="max-w-4xl">
      <h1 className="font-display text-3xl font-bold">Administración</h1>
      <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {([["Usuarios", profiles.length], ["Verificados", verified.size], ["Pidieron verificación", requests.length]] as const).map(([l, n]) => (
          <div key={l} className="rounded-xl border border-line bg-surface p-3"><p className="font-display text-2xl font-bold text-neon">{n}</p><p className="text-xs text-mute">{l}</p></div>
        ))}
      </div>
      <div className="mt-5 flex flex-wrap gap-2" role="tablist">
        {tabs.map(([t, l, n]) => (
          <button key={t} type="button" role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={cx("chip", tab === t && "chip-on")}>
            {l} <span className="ml-1.5 text-mute">{n}</span>
          </button>
        ))}
      </div>

      <div className="mt-5 space-y-3">
        {tab === "usuarios" && (
          <>
            <input value={find} onChange={(e) => setFind(e.target.value)} placeholder="Buscar usuario" className="input" />
            {[...profiles]
              .filter((p) => p.name.toLowerCase().includes(find.trim().toLowerCase()))
              .sort((a, b) => tsMs(b.createdAt) - tsMs(a.createdAt))
              .map((p) => (
                <div key={p.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-surface p-4">
                  <div className="min-w-0">
                    <p className="flex items-center gap-1.5 font-medium"><span className="truncate">{p.name}</span>{verified.has(p.id) && <span className="text-xs text-neon">✔ Verificado</span>}{p.hidden && <span className="text-xs text-mute">(oculto)</span>}</p>
                    <p className="text-sm text-mute">{p.cat} · {followers.get(p.id) ?? 0} seguidores · {(p.works ?? []).length} trabajos{p.createdAt ? ` · alta ${new Date(tsMs(p.createdAt)).toLocaleDateString("es-AR")}` : ""}</p>
                  </div>
                  <div className="flex gap-2">
                    <Link to={`/editor/${p.id}`} className="btn-ghost !py-1.5">Ver perfil</Link>
                    <button type="button" className={verified.has(p.id) ? "btn-ghost !py-1.5" : "btn-primary !py-1.5"} onClick={() => void run(async () => { await setVerified(p.id, !verified.has(p.id)); await refresh(); }, verified.has(p.id) ? "Verificación quitada." : "Cuenta verificada.")}>
                      {verified.has(p.id) ? "Quitar verificación" : "Verificar"}
                    </button>
                  </div>
                </div>
              ))}
          </>
        )}

        {tab === "verificaciones" &&
          (requests.length ? requests.map((r) => (
            <div key={r.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-surface p-4">
              <div>
                <p className="font-medium">{r.name || nameOf(r.id)}</p>
                <p className="text-sm text-mute">Pidió ser verificado</p>
              </div>
              <div className="flex gap-2">
                <Link to={`/editor/${r.id}`} className="btn-ghost !py-1.5">Ver perfil</Link>
                <button type="button" className="btn-primary !py-1.5" onClick={() => void run(async () => { await approveVerification(r.id); await refresh(); }, "Cuenta verificada.")}>Aprobar</button>
                <button type="button" className="btn-ghost !py-1.5" onClick={() => void run(() => rejectVerification(r.id))}>Rechazar</button>
              </div>
            </div>
          )) : <EmptyState title="No hay solicitudes" />)}

        {tab === "reportes" &&
          (reports.length ? reports.map((r) => (
            <div key={r.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-surface p-4">
              <div className="min-w-0">
                <p className="font-medium">{nameOf(r.profileId)}</p>
                <p className="break-words text-sm text-mute">{r.reason}</p>
              </div>
              <div className="flex gap-2">
                <Link to={`/editor/${r.profileId}`} className="btn-ghost !py-1.5">Ver perfil</Link>
                <button type="button" className="btn-ghost !py-1.5" onClick={() => void run(() => dismissReport(r.id))}>Descartar</button>
              </div>
            </div>
          )) : <EmptyState title="No hay reportes" />)}

        {tab === "pagos" &&
          (payments.length ? payments.map((r) => (
            <div key={r.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-surface p-4">
              <div className="min-w-0">
                <p className="font-medium">{r.name || nameOf(r.id)}</p>
                <p className="break-all text-sm text-mute">ID de transacción: <span className="text-white">{r.txn}</span></p>
                <p className="text-xs text-mute">Comprobalo en tu PayPal (USD 5) antes de aprobar.</p>
              </div>
              <div className="flex gap-2">
                <Link to={`/editor/${r.id}`} className="btn-ghost !py-1.5">Ver perfil</Link>
                <button type="button" className="btn-primary !py-1.5" onClick={() => void run(() => approvePro(r.id), "Pro activado.")}>Aprobar</button>
                <button type="button" className="btn-ghost !py-1.5" onClick={() => void run(() => rejectPro(r.id))}>Rechazar</button>
              </div>
            </div>
          )) : <EmptyState title="No hay pagos pendientes" />)}

        {tab === "destacados" &&
          (featured.size ? [...featured].map((id) => (
            <div key={id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-surface p-4">
              <p className="font-medium">{nameOf(id)}</p>
              <div className="flex gap-2">
                <Link to={`/editor/${id}`} className="btn-ghost !py-1.5">Ver perfil</Link>
                <button type="button" className="btn-ghost !py-1.5" onClick={() => void run(async () => { await setFeatured(id, false); await refresh(); })}>Quitar</button>
              </div>
            </div>
          )) : <EmptyState title="No hay editores destacados">Entrá al perfil de un editor y tocá Destacar en el inicio.</EmptyState>)}
      </div>
    </div>
  );
}
