import { Link } from "react-router-dom";
import { LEGAL, MIN_AGE } from "../config";

interface Section {
  title: string;
  body: string[];
}

function LegalPage({ title, sections }: { title: string; sections: Section[] }) {
  return (
    <article className="mx-auto max-w-3xl">
      <Link to="/" className="text-sm text-mute hover:text-white">‹ Volver a Chatcrack</Link>
      <h1 className="mt-4 font-display text-3xl font-bold">{title}</h1>
      <p className="mt-1 text-sm text-mute">Última actualización: {LEGAL.date}</p>
      <p className="mt-4 rounded-xl border border-violet/40 bg-violet/10 p-3 text-sm">
        Borrador base. Completá los datos pendientes en <code>src/config.ts</code> y pedí que lo revise un abogado antes de promocionar el sitio.
      </p>
      <div className="mt-6 space-y-6">
        {sections.map((s, i) => (
          <section key={s.title}>
            <h2 className="font-display text-xl font-semibold">{i + 1}. {s.title}</h2>
            {s.body.map((t) => <p key={t} className="mt-2 leading-relaxed text-mute">{t}</p>)}
          </section>
        ))}
      </div>
    </article>
  );
}

export function Privacy() {
  return (
    <LegalPage
      title="Política de privacidad"
      sections={[
        { title: "Quién es responsable", body: [`Chatcrack es operada por ${LEGAL.owner}, de ${LEGAL.country}. Contacto: ${LEGAL.email}.`] },
        { title: "Qué datos recolectamos", body: ["Al iniciar sesión con Google recibimos un identificador de cuenta y el nombre de tu cuenta de Google. Además guardamos lo que vos cargás: los datos de tu perfil (alias, categoría, descripción, precio, avatar, redes y contacto que decidas publicar), imágenes de tu portafolio, mensajes y notas de voz enviados en los chats, a quién seguís y quién te sigue, y los reportes que envíes."] },
        { title: "Para qué los usamos", body: ["Para crear tu cuenta y tu perfil, mostrarlo en el directorio, permitir mensajes entre usuarios, mostrar seguidores, revisar solicitudes de verificación, atender reportes y mantener la seguridad del sitio. No vendemos tus datos ni mostramos publicidad con ellos."] },
        { title: "Qué es público y qué es privado", body: ["Público: tu perfil, tus trabajos, tus redes y datos de contacto que cargues, tu insignia de verificación y tu cantidad de seguidores. Privado: tus mensajes, que solo pueden leer las dos personas de cada conversación. Por razones técnicas y de moderación, quien administra el proyecto puede acceder a la base de datos; solo lo hará para resolver problemas técnicos, reportes o pedidos legales."] },
        { title: "Servicios de terceros", body: ["Usamos Google Firebase (Authentication, Firestore, Storage y Hosting) para el inicio de sesión, el almacenamiento y la publicación del sitio. Google puede procesar datos en servidores fuera de tu país. Al enviar un mensaje por WhatsApp, Instagram, Discord, TikTok o YouTube, esas plataformas se rigen por sus propias políticas."] },
        { title: "Menores de edad", body: [`El servicio es para personas de ${MIN_AGE} años o más. Las personas menores de 18 deben usarlo con autorización de su madre, padre o tutor. Recomendamos a los menores no publicar teléfono, dirección ni otros datos sensibles. Si sos madre, padre o tutor y querés que eliminemos una cuenta, escribinos.`] },
        { title: "Cuánto tiempo guardamos los datos", body: ["Mientras tu cuenta esté activa. Podés eliminar tu perfil desde Mi panel, lo que borra tu perfil, tus imágenes y tus seguidores. Para borrar también tus mensajes, escribinos y lo hacemos en un plazo razonable."] },
        { title: "Tus derechos", body: [`Podés pedir acceso, corrección o eliminación de tus datos escribiendo a ${LEGAL.email}. Si estás en Argentina, la Ley 25.326 de Protección de Datos Personales te da derechos de acceso, rectificación y supresión, y la Agencia de Acceso a la Información Pública (AAIP) es el organismo de control.`] },
        { title: "Avisos y cookies", body: ["El sitio usa almacenamiento técnico del navegador para mantener tu sesión. Si activás los avisos, te mostramos notificaciones del navegador cuando recibís un mensaje con el sitio abierto."] },
        { title: "Cambios", body: ["Si cambiamos esta política, actualizaremos la fecha de arriba."] },
      ]}
    />
  );
}

export function Terms() {
  return (
    <LegalPage
      title="Términos y condiciones"
      sections={[
        { title: "Qué es Chatcrack", body: [`Es un red social donde las personas crean perfiles, comparten contenido, siguen cuentas y se envían mensajes. Es operado por ${LEGAL.owner}. Free Fire es una marca de Garena; este sitio no está afiliado, patrocinado ni respaldado por Garena.`] },
        { title: "Sin comisiones ni pagos", body: ["La academia no cobra comisión, no procesa pagos y no es parte de los acuerdos entre editores y clientes. El precio, el cobro, la entrega y cualquier reclamo se resuelven directamente entre ellos. Recomendamos acordar todo por escrito y desconfiar de pagos por adelantado a desconocidos."] },
        { title: "Tu cuenta", body: [`Para crear un perfil iniciás sesión con Google. Sos responsable de tu cuenta y de lo que publicás. Tenés que tener ${MIN_AGE} años o más; si sos menor de 18, necesitás autorización de tu madre, padre o tutor.`] },
        { title: "Contenido permitido", body: ["Solo podés subir contenido propio o que tengas derecho a usar. Está prohibido publicar: contenido sexual o que involucre a menores de forma inadecuada, violencia, acoso, discriminación, estafas, suplantación de identidad, material con derechos de terceros sin permiso, virus o enlaces engañosos, y datos personales de otras personas."] },
        { title: "Mensajes", body: ["Usá los mensajes para tratar trabajos de edición. No envíes spam, amenazas ni contenido ofensivo. Podés reportar perfiles desde su página."] },
        { title: "Moderación", body: ["Podemos ocultar o eliminar perfiles, trabajos o cuentas que incumplan estos términos, y revisar reportes, sin aviso previo cuando sea necesario para proteger a la comunidad."] },
        { title: "Insignia de verificado", body: ["La insignia indica que la plataforma revisó la cuenta. No garantiza la calidad del trabajo, los resultados ni el cumplimiento de acuerdos entre editor y cliente."] },
        { title: "Tu contenido", body: ["Seguís siendo titular de lo que subís. Nos das permiso para mostrarlo dentro del sitio mientras tu perfil esté publicado."] },
        { title: "Responsabilidad", body: ["El sitio se ofrece \"tal cual\", sin garantías de disponibilidad continua. En la medida que la ley lo permita, no somos responsables por acuerdos, pagos o conflictos entre usuarios, ni por contenido publicado por terceros."] },
        { title: "Privacidad", body: ["El tratamiento de tus datos se explica en la Política de privacidad."] },
        { title: "Ley aplicable y contacto", body: [`Estos términos se rigen por las leyes de ${LEGAL.country}. Consultas y reclamos: ${LEGAL.email}.`] },
      ]}
    />
  );
}
