import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Search } from "lucide-react";
import { ProfileCard } from "../components/ProfileCard";
import { ProfileCardSkeleton } from "../components/Skeleton";
import { EmptyState } from "../components/EmptyState";
import { CATS } from "../config";
import { useAuth } from "../hooks/useAuth";
import { useData } from "../hooks/useData";
import { useSignIn } from "../hooks/useSignIn";
import { okImg, tsMs } from "../lib/utils";
import { suggest } from "../lib/suggest";
import { Avatar as ParaAvatar, VerifiedBadge as ParaBadge } from "../components/Avatar";

export default function Home() {
  const { profiles, verified, featured, followers, loading } = useData();
  const { user } = useAuth();
  const signIn = useSignIn();
  const navigate = useNavigate();
  const [q, setQ] = useState("");

  const onSearch = (e: FormEvent) => {
    e.preventDefault();
    navigate(q.trim() ? `/editores?q=${encodeURIComponent(q.trim())}` : "/editores");
  };

  const available = profiles.filter((p) => p.av).length;
  const verifiedCount = profiles.filter((p) => verified.has(p.id)).length;
  const highlighted = profiles.filter((p) => featured.has(p.id)).slice(0, 4);
  const recent = [...profiles].sort((a, b) => tsMs(b.createdAt) - tsMs(a.createdAt)).slice(0, 4);
  const paraTi = suggest(profiles, verified, followers, new Set(user ? [user.uid] : [])).slice(0, 10);
  const showcase = profiles
    .map((p) => ({ p, w: (p.works ?? []).find((w) => okImg(w.url)) }))
    .filter((x): x is { p: (typeof profiles)[number]; w: { url: string; title: string } } => !!x.w)
    .slice(0, 8);

  return (
    <div className="space-y-10">
      <section className="relative overflow-hidden rounded-3xl border border-line bg-surface px-6 py-14 sm:px-12 sm:py-20">
        <span
          aria-hidden="true"
          className="pointer-events-none absolute -right-6 -top-10 select-none font-display text-[16rem] font-bold leading-none sm:text-[22rem]"
          style={{ color: "transparent", WebkitTextStroke: "2px rgba(138,77,255,.45)" }}
        >
          166
        </span>
        <div className="relative max-w-2xl">
          <h1 className="font-display text-4xl font-bold leading-[1.05] sm:text-6xl">
            Conectá, compartí y descubrí gente
          </h1>
          <p className="mt-4 max-w-xl text-lg text-mute">
            Una comunidad original para compartir momentos, descubrir perfiles, seguir personas y hablar por privado.
          </p>
          <form onSubmit={onSearch} className="mt-8 flex max-w-xl gap-2" role="search">
            <label htmlFor="home-q" className="sr-only">Buscar personas</label>
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-mute" />
              <input
                id="home-q"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Buscar personas o perfiles"
                className="input !pl-11 !py-3.5 text-base"
              />
            </div>
            <button type="submit" className="btn-primary px-6">Buscar</button>
          </form>
          {!loading && (
            <p className="mt-4 flex items-center gap-2 text-sm text-mute">
              <span className="h-2 w-2 rounded-full bg-neon shadow-[0_0_8px_#B6FF2E]" />
              {available === 1 ? "1 editor disponible ahora" : `${available} editores disponibles ahora`}
            </p>
          )}
          {!user && (
            <button type="button" onClick={() => void signIn()} className="btn-ghost mt-6">
              Soy editor: crear mi perfil
            </button>
          )}
        </div>
      </section>

      <section aria-label="Estadísticas de la plataforma" className="grid grid-cols-3 gap-3">
        {[
          [loading ? "–" : profiles.length, "Editores"],
          [loading ? "–" : verifiedCount, "Verificados"],
          [loading ? "–" : available, "Con cupo"],
        ].map(([n, l]) => (
          <div key={l as string} className="rounded-2xl border border-line bg-surface px-4 py-5">
            <p className="font-display text-3xl font-bold text-neon">{n}</p>
            <p className="text-sm text-mute">{l}</p>
          </div>
        ))}
      </section>

      {paraTi.length > 0 && (
        <section>
          <div className="mb-4 flex items-end justify-between">
            <h2 className="font-display text-2xl font-semibold">Para ti</h2>
            <span className="text-sm text-mute">Verificados y más seguidos</span>
          </div>
          <div className="-mx-4 flex gap-3 overflow-x-auto px-4 pb-2">
            {paraTi.map((p) => (
              <Link key={p.id} to={`/editor/${p.id}`} className="w-40 shrink-0 rounded-2xl border border-line bg-surface p-4 text-center transition hover:border-violet hover:shadow-violet">
                <ParaAvatar profile={p} size={64} className="mx-auto" />
                <p className="mt-3 flex items-center justify-center gap-1 font-medium"><span className="truncate">{p.name}</span>{verified.has(p.id) && <ParaBadge />}</p>
                <p className="truncate text-xs text-mute">{p.cat}</p>
                <p className="mt-1 text-xs text-neon">{followers.get(p.id) ?? 0} seguidores</p>
              </Link>
            ))}
          </div>
        </section>
      )}

      <section>
        <h2 className="mb-4 font-display text-2xl font-semibold">Categorías de trabajo</h2>
        <div className="flex flex-wrap gap-2">
          {CATS.map((c) => {
            const n = profiles.filter((p) => p.cat === c).length;
            return (
              <Link key={c} to={`/editores?cat=${encodeURIComponent(c)}`} className="chip">
                {c}
                {!loading && <span className="ml-2 text-mute">{n}</span>}
              </Link>
            );
          })}
        </div>
      </section>

      {highlighted.length > 0 && (
        <section>
          <h2 className="mb-4 font-display text-2xl font-semibold">Perfiles destacados</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {highlighted.map((p) => <ProfileCard key={p.id} p={p} mine={p.id === user?.uid} />)}
          </div>
        </section>
      )}

      <section>
        <div className="mb-4 flex items-end justify-between gap-4">
          <h2 className="font-display text-2xl font-semibold">Personas nuevas</h2>
          <Link to="/editores" className="text-sm font-medium text-neon hover:underline">Explorar personas</Link>
        </div>
        {loading ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 4 }, (_, i) => <ProfileCardSkeleton key={i} />)}
          </div>
        ) : recent.length ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {recent.map((p) => <ProfileCard key={p.id} p={p} mine={p.id === user?.uid} />)}
          </div>
        ) : (
          <EmptyState title="Todavía no hay editores">
            Iniciá sesión con Google y creá el primer perfil desde Mi panel.
          </EmptyState>
        )}
      </section>

      {showcase.length > 0 && (
        <section>
          <h2 className="mb-4 font-display text-2xl font-semibold">Publicaciones de la comunidad</h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {showcase.map(({ p, w }) => (
              <Link
                key={p.id}
                to={`/editor/${p.id}`}
                className="group relative block aspect-video overflow-hidden rounded-xl border border-line focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neon"
              >
                <img src={w.url} alt={w.title || `Trabajo de ${p.name}`} loading="lazy" className="h-full w-full object-cover transition group-hover:scale-105" />
                <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent p-2 text-xs font-medium">{p.name}</span>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
