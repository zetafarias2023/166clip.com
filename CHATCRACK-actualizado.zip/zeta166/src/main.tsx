import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import { AuthProvider } from "./hooks/useAuth";
import { CallProvider } from "./hooks/useCall";
import { ChatProvider } from "./hooks/useChat";
import { ListsProvider } from "./hooks/useLists";
import { DataProvider } from "./hooks/useData";
import { ToastProvider } from "./hooks/useToast";
import "./styles/index.css";

if (localStorage.getItem("z166.still") === "1") document.documentElement.classList.add("still");

createRoot(document.getElementById("root") as HTMLElement).render(
  <StrictMode>
    <BrowserRouter>
      <ToastProvider>
        <AuthProvider>
          <ListsProvider>
          <DataProvider>
            <ChatProvider>
              <CallProvider>
                <App />
              </CallProvider>
            </ChatProvider>
          </DataProvider>
          </ListsProvider>
        </AuthProvider>
      </ToastProvider>
    </BrowserRouter>
  </StrictMode>,
);

if ("serviceWorker" in navigator && import.meta.env.PROD) {
  window.addEventListener("load", () => void navigator.serviceWorker.register("/sw.js").catch(() => undefined));
}
