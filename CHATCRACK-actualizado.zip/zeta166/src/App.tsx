import { lazy, Suspense } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { Layout } from "./components/Layout";
import { Skeleton } from "./components/Skeleton";
import Home from "./pages/Home";
import Editors from "./pages/Editors";
import EditorDetail from "./pages/EditorDetail";
import NotFound from "./pages/NotFound";
import { Privacy, Terms } from "./pages/Legal";

// Estas pantallas pesan más y se cargan solo cuando se entra a ellas.
const Messages = lazy(() => import("./pages/Messages"));
const Panel = lazy(() => import("./pages/Panel"));
const Admin = lazy(() => import("./pages/Admin"));
const Cuenta = lazy(() => import("./pages/Cuenta"));

const Loading = () => <Skeleton className="h-64" />;

export default function App() {
  return (
    <Suspense fallback={<Loading />}>
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<Navigate to="/mensajes" replace />} />
          <Route path="inicio" element={<Home />} />
          <Route path="editores" element={<Editors />} />
          <Route path="editor/:id" element={<EditorDetail />} />
          <Route path="mensajes" element={<Messages />} />
          <Route path="mensajes/:otherId" element={<Messages />} />
          <Route path="panel" element={<Panel />} />
          <Route path="ajustes" element={<Navigate to="/cuenta" replace />} />
          <Route path="cuenta" element={<Cuenta />} />
          <Route path="cuenta/:section" element={<Cuenta />} />
          <Route path="admin" element={<Admin />} />
          <Route path="privacidad" element={<Privacy />} />
          <Route path="terminos" element={<Terms />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </Suspense>
  );
}
