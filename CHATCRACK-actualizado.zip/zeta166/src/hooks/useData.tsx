import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { collection, doc, getDoc, getDocs, limit, query, serverTimestamp, setDoc } from "firebase/firestore";
import { useAuth } from "./useAuth";
import { db } from "../firebase/client";
import { fetchProfile, fetchProfiles } from "../services/profiles";
import type { Profile } from "../types";

interface DataApi {
  profiles: Profile[];
  verified: Set<string>;
  featured: Set<string>;
  followers: Map<string, number>;
  loading: boolean;
  refresh: () => Promise<void>;
}

const Ctx = createContext<DataApi | null>(null);

export function useData(): DataApi {
  const v = useContext(Ctx);
  if (!v) throw new Error("useData debe usarse dentro de DataProvider");
  return v;
}

const counts = async () => {
  const m = new Map<string, number>();
  (await getDocs(query(collection(db, "follows"), limit(5000)))).docs.forEach((d) => {
    const f = (d.data() as { followed?: string }).followed;
    if (f) m.set(f, (m.get(f) ?? 0) + 1);
  });
  return m;
};

const ids = async (name: string) => new Set((await getDocs(collection(db, name))).docs.map((d) => d.id));

export function DataProvider({ children }: { children: ReactNode }) {
  const { user, isOwner } = useAuth();
  const [all, setProfiles] = useState<Profile[]>([]);
  const [verified, setVerified] = useState<Set<string>>(new Set());
  const [featured, setFeatured] = useState<Set<string>>(new Set());
  const [followers, setFollowers] = useState<Map<string, number>>(new Map());
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const [p, v, f, c] = await Promise.all([
        fetchProfiles(),
        ids("verified"),
        ids("featured"),
        counts().catch(() => new Map<string, number>()),
      ]);
      setProfiles(p);
      setVerified(v);
      setFeatured(f);
      setFollowers(c);
    } catch {
      /* se queda con lo que ya había; las pantallas muestran el estado vacío */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  // El dueño siempre tiene la insignia de verificado: se crea sola la primera vez que entra.
  useEffect(() => {
    if (!user || !isOwner) return;
    (async () => {
      try {
        const ref = doc(db, "verified", user.uid);
        if (!(await getDoc(ref)).exists()) {
          await setDoc(ref, { at: serverTimestamp() });
          await refresh();
        }
      } catch {
        /* se reintenta en el próximo inicio de sesión */
      }
    })();
  }, [user, isOwner, refresh]);

  // Los perfiles ocultos (Ajustes) no salen en el directorio, salvo el propio.
  const profiles = useMemo(() => all.filter((p) => !p.hidden || p.id === user?.uid), [all, user?.uid]);

  const value = useMemo(
    () => ({ profiles, verified, featured, followers, loading, refresh }),
    [profiles, verified, featured, followers, loading, refresh],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

/** Busca el perfil en la lista ya cargada; si no está, lo pide a Firestore. */
export function useProfile(id?: string) {
  const { profiles } = useData();
  const found = profiles.find((p) => p.id === id);
  const [extra, setExtra] = useState<Profile | null | undefined>(undefined);

  useEffect(() => {
    if (!id || found) {
      setExtra(undefined);
      return;
    }
    let alive = true;
    fetchProfile(id)
      .then((p) => alive && setExtra(p))
      .catch(() => alive && setExtra(null));
    return () => {
      alive = false;
    };
  }, [id, found]);

  return { profile: found ?? extra ?? null, loading: !!id && !found && extra === undefined };
}
