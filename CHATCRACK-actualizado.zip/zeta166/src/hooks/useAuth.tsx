import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  GoogleAuthProvider, onAuthStateChanged, signInWithPopup, signInWithRedirect, signOut as fbSignOut, type User,
} from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { auth, db } from "../firebase/client";
import { OWNER_EMAIL } from "../config";
import { isInAppBrowser } from "../lib/utils";

interface AuthApi {
  user: User | null;
  loading: boolean;
  isAdmin: boolean;
  /** true solo para tu Gmail de dueño (ver README). */
  isOwner: boolean;
  /** true si la web se abrió dentro del navegador de TikTok, Instagram, etc. */
  inApp: boolean;
  /** Devuelve un mensaje de error en español, o null si salió bien. */
  signIn: () => Promise<string | null>;
  signOut: () => Promise<void>;
}

const Ctx = createContext<AuthApi | null>(null);

export function useAuth(): AuthApi {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth debe usarse dentro de AuthProvider");
  return v;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isOwner, setIsOwner] = useState(false);
  const inApp = useMemo(isInAppBrowser, []);

  useEffect(
    () =>
      onAuthStateChanged(auth, async (u) => {
        const owner = !!u?.email && u.emailVerified && u.email.toLowerCase() === OWNER_EMAIL.toLowerCase();
        let admin = owner;
        if (u && !owner) {
          try {
            admin = (await getDoc(doc(db, "admins", u.uid))).exists();
          } catch {
            admin = false;
          }
        }
        setUser(u);
        setIsAdmin(admin);
        setIsOwner(owner);
        setLoading(false);
      }),
    [],
  );

  const signIn = useCallback(async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
      return null;
    } catch (e) {
      const code = (e as { code?: string }).code ?? "";
      if (code === "auth/popup-closed-by-user" || code === "auth/cancelled-popup-request") return null;
      if (code === "auth/popup-blocked" || code === "auth/operation-not-supported-in-this-environment") {
        try {
          await signInWithRedirect(auth, provider);
          return null;
        } catch {
          return "No se pudo abrir el inicio de sesión. Probá abrir la web en Chrome o Safari.";
        }
      }
      if (code === "auth/unauthorized-domain") {
        return "Este dominio no está autorizado en Firebase. Agregalo en Authentication > Configuración > Dominios autorizados.";
      }
      return "No se pudo iniciar sesión (" + (code || "error desconocido") + ").";
    }
  }, []);

  const signOut = useCallback(() => fbSignOut(auth), []);

  const value = useMemo(
    () => ({ user, loading, isAdmin, isOwner, inApp, signIn, signOut }),
    [user, loading, isAdmin, isOwner, inApp, signIn, signOut],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
