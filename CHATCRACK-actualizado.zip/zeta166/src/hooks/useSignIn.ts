import { useCallback } from "react";
import { useAuth } from "./useAuth";
import { useToast } from "./useToast";

/** Inicia sesión mostrando un aviso si falla. Devuelve true si ya hay sesión al terminar. */
export function useSignIn() {
  const { user, signIn, inApp } = useAuth();
  const { push } = useToast();
  return useCallback(async () => {
    if (user) return true;
    if (inApp) {
      push("Google no permite iniciar sesión dentro de esta app. Abrí la web en Chrome o Safari.", { tone: "error" });
      return false;
    }
    const err = await signIn();
    if (err) {
      push(err, { tone: "error" });
      return false;
    }
    return true;
  }, [user, signIn, inApp, push]);
}
