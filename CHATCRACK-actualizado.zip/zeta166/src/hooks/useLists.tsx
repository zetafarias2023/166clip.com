import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { emptyLists, subscribeLists, toggleInList, type ListKey, type Lists } from "../services/lists";
import { useAuth } from "./useAuth";

interface ListsApi {
  lists: Lists;
  toggle: (key: ListKey, id: string, on?: boolean) => Promise<void>;
}

const Ctx = createContext<ListsApi | null>(null);

export function useLists(): ListsApi {
  const v = useContext(Ctx);
  if (!v) throw new Error("useLists debe usarse dentro de ListsProvider");
  return v;
}

export function ListsProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const uid = user?.uid;
  const [lists, setLists] = useState<Lists>(emptyLists());

  useEffect(() => {
    setLists(emptyLists());
    if (!uid) return;
    return subscribeLists(uid, setLists);
  }, [uid]);

  const toggle = useCallback(
    async (key: ListKey, id: string, on?: boolean) => {
      if (!uid) return;
      await toggleInList(uid, key, id, on ?? !lists[key].includes(id));
    },
    [uid, lists],
  );

  const value = useMemo(() => ({ lists, toggle }), [lists, toggle]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
