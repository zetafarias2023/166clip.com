import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { beep, tsMs } from "../lib/utils";
import { pingPresence, subscribeConversations } from "../services/chat";
import { registerPush } from "../services/push";
import type { Conversation } from "../types";
import { useAuth } from "./useAuth";
import { useData } from "./useData";
import { useLists } from "./useLists";
import { useToast } from "./useToast";

interface ChatApi {
  convs: Conversation[];
  unread: number;
  isUnread: (c: Conversation) => boolean;
  /** La pantalla de mensajes avisa qué chat está mirando, para no mostrar avisos duplicados. */
  setActiveChat: (id: string | null) => void;
}

const Ctx = createContext<ChatApi | null>(null);

export function useChat(): ChatApi {
  const v = useContext(Ctx);
  if (!v) throw new Error("useChat debe usarse dentro de ChatProvider");
  return v;
}

export function ChatProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const { push } = useToast();
  const navigate = useNavigate();
  const [convs, setConvs] = useState<Conversation[]>([]);
  const { lists } = useLists();
  const listsRef = useRef(lists);
  listsRef.current = lists;
  const active = useRef<string | null>(null);
  const lastAt = useRef<Record<string, number>>({});
  const first = useRef(true);

  const uid = user?.uid;
  const { profiles } = useData();
  const hiddenProfile = !!profiles.find((p) => p.id === uid)?.hidden;

  // Presencia: solo si tu perfil no está oculto.
  useEffect(() => {
    if (!uid || hiddenProfile) return;
    const go = () => {
      if (!document.hidden) pingPresence(uid).catch(() => undefined);
    };
    go();
    const t = window.setInterval(go, 60000);
    document.addEventListener("visibilitychange", go);
    return () => {
      window.clearInterval(t);
      document.removeEventListener("visibilitychange", go);
    };
  }, [uid, hiddenProfile]);

  useEffect(() => {
    if (uid && typeof Notification !== "undefined" && Notification.permission === "granted") void registerPush(uid);
  }, [uid]);

  useEffect(() => {
    setConvs([]);
    first.current = true;
    lastAt.current = {};
    if (!uid) return;
    return subscribeConversations(uid, (rows) => {
      rows.forEach((c) => {
        const t = tsMs(c.lastAt);
        const incoming = c.lastFrom !== uid && t > (lastAt.current[c.id] ?? 0);
        if (!first.current && incoming) {
          const other = c.participants.find((p) => p !== uid) ?? "";
          const name = c.names?.[other] || "Usuario";
          const viewing = active.current === c.id && !document.hidden;
          if (!viewing && !listsRef.current.muted.includes(other) && !listsRef.current.blocked.includes(other)) {
            push(`${name}: ${c.lastText || "Nuevo mensaje"}`, { onClick: () => navigate(`/mensajes/${other}`) });
            beep();
            if ("Notification" in window && Notification.permission === "granted" && document.hidden) {
              const n = new Notification(name, { body: c.lastText || "Nuevo mensaje", tag: c.id });
              n.onclick = () => {
                window.focus();
                navigate(`/mensajes/${other}`);
              };
            }
          }
        }
        lastAt.current[c.id] = t;
      });
      first.current = false;
      setConvs(rows);
    });
  }, [uid, push, navigate]);

  const isUnread = (c: Conversation) =>
    !!uid && c.lastFrom !== uid && tsMs(c.lastAt) > tsMs(c.seen?.[uid]) &&
    !listsRef.current.blocked.includes(c.participants.find((p) => p !== uid) ?? "");
  const unread = convs.filter(isUnread).length;

  useEffect(() => {
    document.title = (unread ? `(${unread}) ` : "") + "Chatcrack";
  }, [unread]);

  const value = useMemo(
    () => ({ convs, unread, isUnread, setActiveChat: (id: string | null) => void (active.current = id) }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [convs, unread, uid],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
