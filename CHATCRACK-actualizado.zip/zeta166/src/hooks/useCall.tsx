import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { addDoc, collection, deleteDoc, doc, onSnapshot, query, serverTimestamp, setDoc, updateDoc, where, type DocumentReference } from "firebase/firestore";
import { Mic, MicOff, Phone, PhoneOff } from "lucide-react";
import { db } from "../firebase/client";
import { explain } from "../lib/errors";
import { beep } from "../lib/utils";
import { Avatar } from "../components/Avatar";
import { useAuth } from "./useAuth";
import { useData } from "./useData";
import { useToast } from "./useToast";

/**
 * Llamadas de voz entre dos personas (WebRTC). Firestore solo se usa para "avisarse" (señalización);
 * el audio va directo entre los dos dispositivos. Funciona mientras la app esté abierta.
 */

type Phase = "calling" | "incoming" | "connecting" | "live";
interface Info {
  id: string;
  peerId: string;
  peerName: string;
  phase: Phase;
}
interface Incoming {
  id: string;
  from: string;
  name: string;
  offer: RTCSessionDescriptionInit;
}

interface CallApi {
  startCall: (peerId: string, peerName: string) => Promise<void>;
  busy: boolean;
}

const Ctx = createContext<CallApi | null>(null);

export function useCall(): CallApi {
  const v = useContext(Ctx);
  if (!v) throw new Error("useCall debe usarse dentro de CallProvider");
  return v;
}

function iceServers(): RTCIceServer[] {
  const env = import.meta.env;
  const servers: RTCIceServer[] = [{ urls: ["stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302"] }];
  // Opcional: un servidor TURN propio ayuda cuando las dos personas están en redes móviles estrictas.
  const raw = ((env.VITE_TURN_URL as string | undefined) ?? "").trim();
  if (raw) {
    const urls = raw.split(",").map((u) => u.trim()).filter(Boolean).map((u) => (/^turns?:/i.test(u) ? u : `turn:${u}`));
    servers.push({ urls, username: (env.VITE_TURN_USER as string) ?? "", credential: (env.VITE_TURN_PASS as string) ?? "" });
  }
  return servers;
}

function newPc(): RTCPeerConnection {
  try {
    return new RTCPeerConnection({ iceServers: iceServers() });
  } catch {
    // Si el TURN está mal escrito, se usa solo STUN en vez de impedir la llamada.
    return new RTCPeerConnection({ iceServers: [{ urls: "stun:stun.l.google.com:19302" }] });
  }
}

const mmss = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

export function CallProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const { profiles } = useData();
  const { push } = useToast();
  const uid = user?.uid;
  const myName = (user?.displayName ?? "Usuario").slice(0, 40);

  const [info, setInfo] = useState<Info | null>(null);
  const [muted, setMuted] = useState(false);
  const [secs, setSecs] = useState(0);

  const infoRef = useRef<Info | null>(null);
  const incomingRef = useRef<Incoming | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const unsubs = useRef<Array<() => void>>([]);
  const timers = useRef<number[]>([]);
  const pending = useRef<RTCIceCandidateInit[]>([]);

  const update = (next: Info | null) => {
    infoRef.current = next;
    setInfo(next);
  };
  const setPhase = (phase: Phase) => {
    if (infoRef.current) update({ ...infoRef.current, phase });
  };

  /** Corta todo lo local (conexión, micrófono, escuchas y relojes). */
  const cleanup = useCallback(() => {
    unsubs.current.forEach((u) => u());
    unsubs.current = [];
    timers.current.forEach((t) => window.clearTimeout(t));
    timers.current = [];
    pcRef.current?.close();
    pcRef.current = null;
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    pending.current = [];
    incomingRef.current = null;
    if (audioRef.current) audioRef.current.srcObject = null;
    infoRef.current = null;
    setInfo(null);
    setMuted(false);
    setSecs(0);
  }, []);

  const hangUp = useCallback(async () => {
    const id = infoRef.current?.id;
    cleanup();
    if (id) await deleteDoc(doc(db, "calls", id)).catch(() => undefined);
  }, [cleanup]);

  // Cierra la llamada si se cierra la sesión.
  useEffect(() => {
    if (!uid) cleanup();
  }, [uid, cleanup]);

  const makePc = (callId: string, me: string, ready?: Promise<void>): RTCPeerConnection => {
    const pc = newPc();
    pcRef.current = pc;
    streamRef.current?.getTracks().forEach((t) => pc.addTrack(t, streamRef.current as MediaStream));
    pc.ontrack = (e) => {
      if (audioRef.current) {
        audioRef.current.srcObject = e.streams[0];
        void audioRef.current.play().catch(() => undefined);
      }
    };
    pc.onicecandidate = (e) => {
      if (!e.candidate) return;
      const c = JSON.stringify(e.candidate.toJSON());
      void (ready ?? Promise.resolve()).then(() => addDoc(collection(db, "calls", callId, "ice"), { from: me, c }).catch(() => undefined));
    };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === "connected") setPhase("live");
      if (pc.connectionState === "failed") {
        push("No se pudo conectar la llamada. Puede ser un problema de red.", { tone: "error" });
        void hangUp();
      }
    };
    const flush = () => {
      const list = pending.current;
      pending.current = [];
      list.forEach((c) => void pc.addIceCandidate(c).catch(() => undefined));
    };
    return Object.assign(pc, { flushIce: flush }) as RTCPeerConnection;
  };

  /** Escucha los candidatos de red de la otra persona. Solo se llama cuando el documento de la llamada ya existe. */
  const listenIce = (pc: RTCPeerConnection, callId: string, me: string) => {
    const unsub = onSnapshot(collection(db, "calls", callId, "ice"), (snap) => {
      snap.docChanges().forEach((ch) => {
        if (ch.type !== "added") return;
        const d = ch.doc.data() as { from?: string; c?: string };
        if (d.from === me || !d.c) return;
        try {
          const cand = JSON.parse(d.c) as RTCIceCandidateInit;
          if (pc.remoteDescription) void pc.addIceCandidate(cand).catch(() => undefined);
          else pending.current.push(cand);
        } catch {
          /* candidato dañado: se ignora */
        }
      });
    }, (e) => console.error("ice", e));
    unsubs.current.push(unsub);
  };

  const getMic = async (): Promise<boolean> => {
    if (!navigator.mediaDevices?.getUserMedia || typeof RTCPeerConnection === "undefined") {
      push("Tu navegador no permite llamadas.", { tone: "error" });
      return false;
    }
    try {
      streamRef.current = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      return true;
    } catch {
      push("No se pudo usar el micrófono. Revisá el permiso del navegador.", { tone: "error" });
      return false;
    }
  };

  const startCall = useCallback(async (peerId: string, peerName: string) => {
    if (!uid) return push("Iniciá sesión para llamar.", { tone: "error" });
    if (infoRef.current) return;
    if (!(await getMic())) return;
    const ref = doc(collection(db, "calls")) as DocumentReference;
    let ok!: () => void;
    const ready = new Promise<void>((r) => { ok = r; });
    update({ id: ref.id, peerId, peerName, phase: "calling" });
    try {
      const pc = makePc(ref.id, uid, ready) as RTCPeerConnection & { flushIce: () => void };
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await setDoc(ref, { from: uid, to: peerId, fromName: myName, status: "ringing", offer: { type: offer.type, sdp: offer.sdp }, at: serverTimestamp() });
      ok();
      listenIce(pc, ref.id, uid);
      unsubs.current.push(onSnapshot(ref, (s) => {
        if (!s.exists()) {
          if (infoRef.current?.id === ref.id) {
            push("La llamada terminó.", { tone: "info" });
            cleanup();
          }
          return;
        }
        const d = s.data() as { status?: string; answer?: RTCSessionDescriptionInit };
        if (d.answer && !pc.remoteDescription) {
          setPhase("connecting");
          void pc.setRemoteDescription(d.answer).then(() => pc.flushIce()).catch(() => undefined);
        }
        if (d.status === "declined") {
          push(`${peerName} rechazó la llamada.`, { tone: "info" });
          void hangUp();
        }
      }, (err) => { console.error("call", err); push(explain(err, "Se perdió la conexión con la llamada."), { tone: "error" }); cleanup(); }));
      timers.current.push(window.setTimeout(() => {
        if (infoRef.current?.id === ref.id && infoRef.current.phase === "calling") {
          push(`${peerName} no respondió.`, { tone: "info" });
          void hangUp();
        }
      }, 40_000));
    } catch (e) {
      cleanup();
      console.error("llamada", e);
      push(explain(e, `No se pudo iniciar la llamada: ${(e as Error)?.message ?? "error"}`), { tone: "error" });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [uid, myName, cleanup, hangUp, push]);

  const accept = async () => {
    const inc = incomingRef.current;
    if (!inc || !uid) return;
    if (!(await getMic())) return void decline();
    update({ id: inc.id, peerId: inc.from, peerName: inc.name, phase: "connecting" });
    const ref = doc(db, "calls", inc.id);
    try {
      const pc = makePc(inc.id, uid) as RTCPeerConnection & { flushIce: () => void };
      listenIce(pc, inc.id, uid);
      await pc.setRemoteDescription(inc.offer);
      pc.flushIce();
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      await updateDoc(ref, { status: "active", answer: { type: answer.type, sdp: answer.sdp } });
      unsubs.current.push(onSnapshot(ref, (s) => {
        if (!s.exists() && infoRef.current?.id === inc.id) {
          push("La llamada terminó.", { tone: "info" });
          cleanup();
        }
      }, () => undefined));
    } catch (e) {
      cleanup();
      console.error("llamada", e);
      push(explain(e, `No se pudo atender la llamada: ${(e as Error)?.message ?? "error"}`), { tone: "error" });
    }
  };

  const decline = async () => {
    const inc = incomingRef.current;
    cleanup();
    if (inc) await updateDoc(doc(db, "calls", inc.id), { status: "declined" }).catch(() => undefined);
  };

  // Escucha llamadas entrantes.
  useEffect(() => {
    if (!uid) return;
    return onSnapshot(
      query(collection(db, "calls"), where("to", "==", uid), where("status", "==", "ringing")),
      (snap) => {
        snap.docChanges().forEach((ch) => {
          if (ch.type === "added") {
            const d = ch.doc.data({ serverTimestamps: "estimate" }) as { from: string; fromName?: string; offer: RTCSessionDescriptionInit; at?: { toMillis(): number } };
            if (Date.now() - (d.at?.toMillis() ?? Date.now()) > 45_000) return; // llamada vieja
            if (infoRef.current) {
              void updateDoc(ch.doc.ref, { status: "declined" }).catch(() => undefined); // ya estás en otra llamada
              return;
            }
            incomingRef.current = { id: ch.doc.id, from: d.from, name: d.fromName || "Alguien", offer: d.offer };
            update({ id: ch.doc.id, peerId: d.from, peerName: d.fromName || "Alguien", phase: "incoming" });
          } else if (ch.type === "removed" && infoRef.current?.id === ch.doc.id && infoRef.current.phase === "incoming") {
            cleanup(); // la otra persona cortó antes de que atendieras
          }
        });
      },
      () => undefined,
    );
  }, [uid, cleanup]);

  // Tono mientras suena y reloj mientras dura.
  const phase = info?.phase;
  useEffect(() => {
    if (phase !== "incoming" && phase !== "calling") return;
    beep();
    const t = window.setInterval(beep, 1800);
    return () => window.clearInterval(t);
  }, [phase]);
  useEffect(() => {
    if (phase !== "live") return;
    const t = window.setInterval(() => setSecs((s) => s + 1), 1000);
    return () => window.clearInterval(t);
  }, [phase]);

  const toggleMute = () => {
    const next = !muted;
    streamRef.current?.getAudioTracks().forEach((t) => (t.enabled = !next));
    setMuted(next);
  };

  const value = useMemo(() => ({ startCall, busy: !!info }), [startCall, info]);
  const peer = info ? profiles.find((p) => p.id === info.peerId) : undefined;
  const label = !info ? "" : info.phase === "calling" ? "Llamando…" : info.phase === "incoming" ? "Te está llamando…" : info.phase === "connecting" ? "Conectando…" : mmss(secs);

  return (
    <Ctx.Provider value={value}>
      {children}
      <audio ref={audioRef} autoPlay playsInline />
      {info && (
        <div role="dialog" aria-label="Llamada" className="fixed inset-x-3 bottom-20 z-[80] mx-auto max-w-sm rounded-2xl border border-line bg-surface p-4 shadow-violet animate-pop md:bottom-6">
          <div className="flex items-center gap-3">
            <Avatar profile={peer} name={info.peerName} size={48} />
            <div className="min-w-0 flex-1">
              <p className="truncate font-display text-lg font-semibold">{info.peerName}</p>
              <p className="text-sm text-neon">{label}</p>
            </div>
          </div>
          <div className="mt-4 flex justify-center gap-3">
            {info.phase === "incoming" ? (
              <>
                <button type="button" onClick={() => void decline()} className="btn-danger" aria-label="Rechazar"><PhoneOff className="h-5 w-5" /> Rechazar</button>
                <button type="button" onClick={() => void accept()} className="btn-primary" aria-label="Atender"><Phone className="h-5 w-5" /> Atender</button>
              </>
            ) : (
              <>
                <button type="button" onClick={toggleMute} className="btn-ghost" aria-pressed={muted} aria-label={muted ? "Activar micrófono" : "Silenciar micrófono"}>
                  {muted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />} {muted ? "Silenciado" : "Silenciar"}
                </button>
                <button type="button" onClick={() => void hangUp()} className="btn-danger" aria-label="Cortar"><PhoneOff className="h-5 w-5" /> Cortar</button>
              </>
            )}
          </div>
        </div>
      )}
    </Ctx.Provider>
  );
}
