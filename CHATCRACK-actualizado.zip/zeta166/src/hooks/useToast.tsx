import { createContext, useCallback, useContext, useMemo, useRef, useState, type ReactNode } from "react";
import { cx } from "../lib/utils";

type Tone = "ok" | "error" | "info";
interface ToastItem {
  id: number;
  text: string;
  tone: Tone;
  onClick?: () => void;
}
interface ToastApi {
  push: (text: string, opts?: { tone?: Tone; onClick?: () => void }) => void;
}

const Ctx = createContext<ToastApi>({ push: () => undefined });
export const useToast = () => useContext(Ctx);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const seq = useRef(0);

  const push = useCallback<ToastApi["push"]>((text, opts) => {
    const id = ++seq.current;
    setItems((cur) => [...cur.slice(-3), { id, text, tone: opts?.tone ?? "info", onClick: opts?.onClick }]);
    window.setTimeout(() => setItems((cur) => cur.filter((t) => t.id !== id)), 5000);
  }, []);

  const api = useMemo(() => ({ push }), [push]);
  const close = (id: number) => setItems((cur) => cur.filter((t) => t.id !== id));

  return (
    <Ctx.Provider value={api}>
      {children}
      <div
        className="pointer-events-none fixed inset-x-3 top-3 z-[100] flex flex-col items-end gap-2 sm:inset-x-auto sm:bottom-4 sm:right-4 sm:top-auto"
        role="status"
        aria-live="polite"
      >
        {items.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => {
              t.onClick?.();
              close(t.id);
            }}
            className={cx(
              "pointer-events-auto max-w-sm animate-pop rounded-xl border bg-raise px-4 py-3 text-left text-sm shadow-xl",
              t.tone === "ok" && "border-neon/60",
              t.tone === "error" && "border-danger/70",
              t.tone === "info" && "border-violet/60",
            )}
          >
            {t.text}
          </button>
        ))}
      </div>
    </Ctx.Provider>
  );
}
