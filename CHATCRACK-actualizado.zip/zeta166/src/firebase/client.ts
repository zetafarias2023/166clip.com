import { initializeApp } from "firebase/app";
import { initializeAppCheck, ReCaptchaV3Provider } from "firebase/app-check";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const env = import.meta.env;

// Esta configuración es pública por diseño (no es una clave secreta). Si definís variables VITE_*, tienen prioridad.
const config = {
  apiKey: env.VITE_FIREBASE_API_KEY || "AIzaSyBooprZzsfe6kSmL7H5gmadRgpx4JcsFno",
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || "zeta166-933e3.firebaseapp.com",
  projectId: env.VITE_FIREBASE_PROJECT_ID || "zeta166-933e3",
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || "zeta166-933e3.firebasestorage.app",
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || "269766305625",
  appId: env.VITE_FIREBASE_APP_ID || "1:269766305625:web:808af181fddf4ce30f8e48",
};

export const app = initializeApp(config);

// App Check: solo se activa si cargaste la clave de reCAPTCHA v3 (ver README).
if (env.VITE_APPCHECK_SITE_KEY) {
  initializeAppCheck(app, {
    provider: new ReCaptchaV3Provider(env.VITE_APPCHECK_SITE_KEY as string),
    isTokenAutoRefreshEnabled: true,
  });
}

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
