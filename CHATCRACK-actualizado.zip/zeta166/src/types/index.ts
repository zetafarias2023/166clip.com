import type { Timestamp } from "firebase/firestore";

export interface Work {
  url: string;
  title: string;
}

export interface Profile {
  id: string;
  name: string;
  cat: string;
  soft?: string;
  price?: string;
  bio?: string;
  yt?: string;
  tt?: string;
  ig?: string;
  wa?: string;
  dc?: string;
  p1?: string;
  p2?: string;
  p3?: string;
  col?: number;
  av?: boolean;
  works?: Work[];
  avatarUrl?: string;
  avatarId?: string;
  bannerUrl?: string;
  createdAt?: Timestamp;
  hidden?: boolean;
}

export type ProfileInput = Omit<Profile, "id" | "createdAt">;

export interface Conversation {
  id: string;
  participants: string[];
  names?: Record<string, string>;
  lastText?: string;
  lastFrom?: string;
  lastAt?: Timestamp | null;
  seen?: Record<string, Timestamp | null>;
  cleared?: Record<string, Timestamp | null>;
  typing?: Record<string, Timestamp | null>;
}

export interface Message {
  id: string;
  from: string;
  text?: string;
  img?: string;
  aud?: string;
  dur?: number;
  reply?: { id: string; text: string; from: string };
  react?: Record<string, string>;
  at?: Timestamp | null;
}

export interface VerifyRequest {
  id: string;
  name?: string;
}

export interface ProRequest {
  id: string;
  name?: string;
  txn?: string;
}

export interface Report {
  id: string;
  profileId: string;
  by: string;
  reason: string;
}
