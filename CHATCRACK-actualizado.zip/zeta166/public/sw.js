// Service worker mínimo: permite instalar la app y abrirla aunque no haya conexión.
const CACHE = "z166-shell-v1";
self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(["/", "/favicon.svg"])).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET" || new URL(req.url).origin !== self.location.origin) return;
  e.respondWith(fetch(req).catch(() => caches.match(req).then((r) => r || caches.match("/"))));
});

// Avisos push (los envía la Cloud Function de functions/index.js)
self.addEventListener("push", (e) => {
  let j = {};
  try { j = e.data ? e.data.json() : {}; } catch { /* sin datos */ }
  const n = j.data || j.notification || j;
  e.waitUntil(self.registration.showNotification(n.title || "Chatcrack", { body: n.body || "Nuevo mensaje", icon: "/icon-192.png", data: { url: n.url || "/mensajes" } }));
});
self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || "/mensajes";
  e.waitUntil(self.clients.matchAll({ type: "window" }).then((cs) => { const c = cs[0]; return c ? (c.navigate(url), c.focus()) : self.clients.openWindow(url); }));
});
